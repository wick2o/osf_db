2004/06/02
MAJOR: UNKNOWN; MINOR: The-Insider and Jelmer;
The Insider Exploit
insider-1st_report_by_insider.txt:Insider found the exploit being used in the wild
insider-doc_by_jelmer.html:Jelmer spent some time on the original exploit in the wild, and finally figured it out
insider-code_by_jelmer:Demo made by Jelmer(Liu Die Yu changed it from JSP to PHP, and made it very easy to use)
#
"insider-code_by_jelmer" was verified to work on winxp-en-pro-sp1-ms04004(MS04-004 = Q832894 = KB832894), but it does not work on winxp-en-pro-sp1-noextrapatch. Well, it's the second 0day which was used in the wild before appearing in public forum like bugtraq.