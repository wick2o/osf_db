<?php
   	sleep(2);
   	header("Location: URL:ms-its:C:\\WINDOWS\\Help\\iexplore.chm::/iegetsrt.htm");
?>
