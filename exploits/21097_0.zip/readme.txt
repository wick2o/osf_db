Testing program for Multiple insufficient argument validation of hooked SSDT function Vulnerability (BTP00000P004AO)
Copyright 2006 by Matousec - Transparent security
http://www.matousec.com/


Terms of Use
------------

The software is provided "as is", without warranty of any kind,
express or implied, including but not limited to the warranties of
merchantability, fitness for a particular purpose and 
noninfringement. In no event shall the copyright holders be liable
for any claim, damages or other liability, whether in an action of
contract, tort or otherwise, arising from, out of or in connection
with the software or the use or other dealings in the software.


Warning
-------

Using this program may damage data on your computer.
Use this software at your own risk.

