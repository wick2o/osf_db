#include "libtag.h"

const int tags=5;
const int presents=6;

const char tag0[]="    ::::::::::. :::::::.. :::::::-.  .,::::::   :::      :::  .    :::.     \r\n"
                  "     `;;;```.;;;;;;;``;;;; ;;,   `';,;;;;''''   ;;;      ;;; .;;,. ;;`;;    \r\n"
                  "      `]]nnn]]'  [[[,/[[[' `[[     [[ [[cccc    [[[      [[[[[/'  ,[[ '[[,  \r\n"
                  "       $$$\"\"     $$$$$$c    $$,    $$ $$\"\"\"\"    $$'     _$$$$,   c$$$cc$$$c \r\n"
                  "       888o      888b \"88bo,888_,o8P' 888oo,__ o88oo,.__\"888\"88o, 888   888,\r\n"
                  "       YMMMb     MMMM   \"W\" MMMMP\"`   \"\"\"\"YUMMM\"\"\"\"YUMMM MMM \"MMP\"YMM   \"\"` \r\n";


const char tag1[]="                          ___ _______ _____   _  _____\r\n"
                  "                          |--'|--<|__>|===|___|-:_|--|\r\n";


const char tag2[]="                                 .___       .__    __            \r\n"
                  "              ______ _______   __| _/ ____  |  |  |  | _______   \r\n"
                  "              \\____ \\\\_  __ \\ / __ |_/ __ \\ |  |  |  |/ /\\__  \\  \r\n"
                  "              |  |_> >|  | \\// /_/ |\\  ___/ |  |__|    <  / __ \\_\r\n"
                  "              |   __/ |__|   \\____ | \\___  >|____/|__|_ \\(____  /\r\n"
                  "              |__|                \\/     \\/            \\/     \\/ \r\n";


const char tag3[]="                     .---..---. .--. .---..-.   .-.,-..---.\r\n"
                  "                     | |-'| |-< | \\ \\| |- | |__ | . < | | |\r\n"
                  "                     `-'  `-'`-'`-'-'`---'`----'`-'`-'`-^-'\r\n";


const char tag4[]="     @@@@@@@   @@@@@@@   @@@@@@@   @@@@@@@@  @@@       @@@  @@@   @@@@@@   \r\n"
                  "     @@@@@@@@  @@@@@@@@  @@@@@@@@  @@@@@@@@  @@@       @@@  @@@  @@@@@@@@  \r\n"
                  "     @@!  @@@  @@!  @@@  @@!  @@@  @@!       @@!       @@!  !@@  @@!  @@@  \r\n"
                  "     !@!  @!@  !@!  @!@  !@!  @!@  !@!       !@!       !@!  @!!  !@!  @!@  \r\n"
                  "     @!@@!@!   @!@!!@!   @!@  !@!  @!!!:!    @!!       @!@@!@!   @!@!@!@!  \r\n"
                  "     !!@!!!    !!@!@!    !@!  !!!  !!!!!:    !!!       !!@!!!    !!!@!!!!  \r\n"
                  "     !!:       !!: :!!   !!:  !!!  !!:       !!:       !!: :!!   !!:  !!!  \r\n"
                  "     :!:       :!:  !:!  :!:  !:!  :!:        :!:      :!:  !:!  :!:  !:!  \r\n"
                  "      ::       ::   :::   :::: ::   :: ::::   :: ::::   ::  :::  ::   :::  \r\n"
                  "      :         :   : :  :: :  :   : :: ::   : :: : :   :   :::   :   : :  \r\n";


const char tag5[]="         @@@@@@@  @@@@@@@  @@@@@@@  @@@@@@@@ @@@      @@@  @@@  @@@@@@ \r\n"
                  "         @@!  @@@ @@!  @@@ @@!  @@@ @@!      @@!      @@!  !@@ @@!  @@@\r\n"
                  "         @!@@!@!  @!@!!@!  @!@  !@! @!!!:!   @!!      @!@@!@!  @!@!@!@!\r\n"
                  "         !!:      !!: :!!  !!:  !!! !!:      !!:      !!: :!!  !!:  !!!\r\n"
                  "          :        :   : : :: :  :  : :: ::: : ::.: :  :   :::  :   : :\r\n";


const char present0[]="\t\t\t\t\e[%dmP\e[%dmr\e[%dmE\e[%dms\e[%dmE\e[%dmn\e[%dmT\e[%dmz\r\n\r\n";
const char present1[]="\t\t\t\t\e[%dmp\e[%dmr\e[%dme\e[%dms\e[%dme\e[%dmn\e[%dmt\e[%dms\r\n\r\n";
const char present2[]="\t\t\t\t\e[%dmp\e[%dmR\e[%dm3\e[%dmz\e[%dm3\e[%dmN\e[%dmt\e[%dmz\r\n\r\n";
const char present3[]="\t\t\t\t\e[%dmp\e[%dmR\e[%dme\e[%dmS\e[%dme\e[%dmN\e[%dmt\e[%dmS\r\n\r\n";
const char present4[]="\t\t\t\t\e[%dmp\e[%dm r\e[%dm e\e[%dm s\e[%dm e\e[%dm n\e[%dm t\e[%dm z\r\n\r\n";
const char present5[]="\t\t\t\t\e[%dmrep\e[%dmr\e[%dme\e[%dms\e[%dme\e[%dmn\e[%dmt\e[%dmz\r\n\r\n";
const char present6[]="\t\t\t\t\e[%dmp\e[%dmr\e[%dme\e[%dms\e[%dme\e[%dmn\e[%dmt\e[%dms\r\n\r\n";

/* Function to output a random ASCii art & quote */
int tag(){
	int a,b,c,d,e,f,g,h,i;
	time_t seconds;
	time(&seconds);
	srand((unsigned int) seconds);	
	a = rand()%(37-31+1)+31;
	fprintf(stderr,"\e[1m\e[%dm",a);
	a = rand()%(tags+1);
	switch(a){
		case 0:
			fprintf(stderr,"\r\n%s\r\n",tag0);
			break;
		case 1:
			fprintf(stderr,"\r\n%s\r\n",tag1);
			break;
                case 2:
			fprintf(stderr,"\r\n%s\r\n",tag2);
			break;
                case 3:
			fprintf(stderr,"\r\n%s\r\n",tag3);
			break;
                case 4:
			fprintf(stderr,"\r\n%s\r\n",tag4);
			break;
                case 5:      
			fprintf(stderr,"\r\n%s\r\n",tag5);
			break;                      
		default:
			fprintf(stderr,"\e[0m");
			return 1;
			break;
	}
	a = rand()%(presents+1);
	i = rand()%(37-31+1)+31;
	h = rand()%(37-31+1)+31;
	g = rand()%(37-31+1)+31;
	f = rand()%(37-31+1)+31;
	e = rand()%(37-31+1)+31;
	d = rand()%(37-31+1)+31;
	c = rand()%(37-31+1)+31;
	b = rand()%(37-31+1)+31;
	switch(a){
		case 0:
			fprintf(stderr,present0,b,c,d,e,f,g,h,i);
			break;
                case 1:
                        fprintf(stderr,present1,b,c,d,e,f,g,h,i);
                        break;

                case 2:
                        fprintf(stderr,present2,b,c,d,e,f,g,h,i);
                        break;

                case 3:
                        fprintf(stderr,present3,b,c,d,e,f,g,h,i);
                        break;

                case 4:
                        fprintf(stderr,present4,b,c,d,e,f,g,h,i);
                        break;
                case 5:
                        fprintf(stderr,present5,b,c,d,e,f,g,h,i);
                        break;
                case 6:
                        fprintf(stderr,present6,b,c,d,e,f,g,h,i);
                        break;
		default:
                	fprintf(stderr,"\e[0m");
                        return 1;
                        break;
        }
	fprintf(stderr,"\e[0m");
	return 0;	
}
