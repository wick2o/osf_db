2005/02/08
MAJOR: Michael Krax and Andreas Sandblad;
Drop to STARTUP Folder II
secunia_advisory_sa11165-doc_by_secunia_dot_com.txt:Secunia published its advisory indicating one extra dot is required is filename
dot_appended_in_filename-doc_by_sandblad.txt:Andreas Sandblad published the source of HTTP header of this attack
ms05014_ack-doc_by_ms.txt:"Acknowledgments" part of ms05-014(microsoft security bulletin) containing original finder and CAN id assigned by cve.mitre.org
miss_ms04038_already-code_by_liudieyu:Liu Die Yu made this proof-of-concept show.
#
"miss_ms04038_already-code_by_liudieyu" was verfied to work on winxpsp2 with ms04-038( = WindowsXP-KB834707-x86-enu.exe). Michael Krax and Andreas Sandblad found it independently; Michael Krax didn't publish any tech info; Andreas Sandblad of Secunia published tech info after the patch; neither provided code. Michael Krax is also known as MIKX.