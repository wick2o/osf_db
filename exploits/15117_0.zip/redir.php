<?php

header('Location: nntp://malicious.news.server/alt.angst');

?>
