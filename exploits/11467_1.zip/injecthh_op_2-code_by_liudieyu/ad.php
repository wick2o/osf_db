<?php
if($_GET["id"]==1)
	readfile("ad_data-1.html");
if($_GET["id"]==2)
	readfile("ad_data-2.html");
if($_GET["id"]==3)
	readfile("ad_data-3.html");
?>
