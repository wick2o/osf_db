HELLO WORLD  for Firmware 2.00-2.80
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

Finally, it's here! As of today, the world of homebrew is no longer restricted to owners of Grand Theft Auto.

Following the publication of a new proof of concept TIFF vulnerability by NOPx86, a team of PSP developers has been working hard to turn it into an opening for homebrew on the PSP. We're pleased to announce that the wait is over, with the release of a Hello World demo that runs on all PSP firmwares that are capable of viewing TIFF images!

To install, just unpack this ZIP file to your PSP's PHOTO folder, and then attempt to view hello_world.tif. Hello World will launch automatically. You may find that occasionally the full screen doesn't show - this is a known problem, just restart your PSP by holding the power button until it turns off, then open the image again. To quit, hold the power button until the PSP turns off.

So what happens next? This shows that we can run code via this exploit. It won't be too hard to develop an eLoader that can use this exploit on v2.0 - v2.6. v2.7+ will be harder, due to extra security, but will happen a little later. Kernel mode is unavailable on v2.8, but it is likely that a downgrader is possible on all other firmwares. But then, with the possibility of kernel homebrew running without the need for a game UMD, why would you need to downgrade?

Full credit is given in the Hello World, but repeated here: Thanks to NOPx86 for the initial proof of concept on the x86 processor, and psp250, Skylark, Joek2100, CSwindle, JimP and Fanjita for the PSP work. Thanks also to Ditlew, HarleyG and our families for general support during this work.