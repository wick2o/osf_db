/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define to empty if the keyword does not work.  */
/* #undef const */

/* Define as __inline if that's what the C compiler calls it.  */
/* #undef inline */

/* Define if you have the ether_hostton function.  */
#define HAVE_ETHER_HOSTTON 1

/* Define if you have the freeifaddrs function.  */
/* #undef HAVE_FREEIFADDRS */

/* Define if you have the strerror function.  */
#define HAVE_STRERROR 1

/* Define if you have the strlcpy function.  */
/* #undef HAVE_STRLCPY */

/* Define if you have the <ifaddrs.h> header file.  */
/* #undef HAVE_IFADDRS_H */

/* Define if you have the <netinet/if_ether.h> header file.  */
#define HAVE_NETINET_IF_ETHER_H 1

/* Define if you have the <netpacket/packet.h> header file.  */
/* #undef HAVE_NETPACKET_PACKET_H */

/* Define if you have the <sys/bufmod.h> header file.  */
/* #undef HAVE_SYS_BUFMOD_H */

/* Define if you have the <sys/dlpi_ext.h> header file.  */
/* #undef HAVE_SYS_DLPI_EXT_H */

/* Define if you have the <sys/ioccom.h> header file.  */
#define HAVE_SYS_IOCCOM_H 1

/* Define if you have the <sys/sockio.h> header file.  */
#define HAVE_SYS_SOCKIO_H 1

/* needed on HP-UX */
/* #undef _HPUX_SOURCE */

/* define if your compiler has __attribute__ */
#define HAVE___ATTRIBUTE__ 1

/* if we have u_int8_t */
/* #undef u_int8_t */

/* if we have u_int16_t */
/* #undef u_int16_t */

/* if we have u_int32_t */
/* #undef u_int32_t */

/* do not use protochain */
/* #undef NO_PROTOCHAIN */

/* IPv6 */
/* #undef INET6 */

/* define if you have a /dev/dlpi */
/* #undef HAVE_DEV_DLPI */

/* /dev/dlpi directory */
/* #undef PCAP_DEV_PREFIX */

/* define on AIX to get certain functions */
/* #undef _SUN */

/* on HP-UX 9.x */
/* #undef HAVE_HPUX9 */

/* on HP-UX 10.20 */
/* #undef HAVE_HPUX10_20 */

/* on sinix */
/* #undef sinix */

/* On solaris */
/* #undef HAVE_SOLARIS */

/* if there's an os_proto.h */
/* #undef HAVE_OS_PROTO_H */

/* if struct sockaddr has sa_len */
#define HAVE_SOCKADDR_SA_LEN 1

/* if ppa_info_t_dl_module_id exists */
/* #undef HAVE_HP_PPA_INFO_T_DL_MODULE_ID_1 */

/* if unaligned access fails */
/* #undef LBL_ALIGN */

