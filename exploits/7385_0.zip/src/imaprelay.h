#ifndef _IMAP_RELAY_
#define _IMAP_RELAY_

#include "smbrelay.h"

int HandleIncommingIMAPRequest(RELAY *relay, char *destinationhostname,int destinationport);

#endif

