#include <stdio.h>

FILE *mmail;

char p1[] = {0x00,0x10};
char p2[] = {0xe8,0xa8,0x32,0x05,0x00,0x90};
char p3[] = {0x81,0x3a,0x75,0x73,0x65,0x72,0x74,0x08,0x81,0x3a,0x55,0x53,0x45,
	     0x52,0x75,0x0a,0x80,0x7a,0x04,0x20,0x75,0x04,0xc6,0x42,0x5f,0x00,
	     0x8b,0x8d,0xa4,0xd0,0xff,0xff,0xc3};

void main(){
  
  printf("MailMax Standard/Professional 4.8 PATCH (popmax 4.8.2.5) (July 20, 2002)\n");
  printf("2c79cbe14ac7d0b8472d3f129fa1df55 (c79cbe14ac7d0b8472d3f129fa1df55@yahoo.com)\n\n");
  

  mmail = fopen("popmax.exe", "rb+");
  
  if(!mmail){printf("'popmax.exe' not found or write protected\n");getchar();return;}
  
  fseek(mmail,0x210,0);
  fwrite(&p1,sizeof(p1),1,mmail);
  fseek(mmail,0xdec1,0);
  fwrite(&p2,sizeof(p2),1,mmail);
  fseek(mmail,0x6116e,0);
  fwrite(&p3,sizeof(p3),1,mmail);
  
  fclose(mmail);
  
  printf("patch successful!\n");
  getchar();

}
